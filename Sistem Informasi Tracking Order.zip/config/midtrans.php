<?php

return [
  'serverKey' => env('MIDTRANS_SERVER_KEY'),
  'clientServer' => env('MIDTRANS_CLIENT_SERVER'),
  'isProduction' => env('MIDTRANS_IS_PRODUCTION'),
  'isSanitized' => env('MIDTRANS_IS_SANITIZED'),
  'is3ds' => env('MIDTRANS_IS_3DS'),
];
