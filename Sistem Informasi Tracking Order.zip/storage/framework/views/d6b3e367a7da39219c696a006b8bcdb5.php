<footer class="footer p-10 bg-[#176B87] text-base-content">
    <aside>
        <img src="assets/logo/logo1.png" alt="" class="h-10 w-10">
        <h1 class="font-bold text-2xl text-white">SMK BANDUNG TIMUR</h1>
        <p class="text-white">Jl. Raya Cinunuk Km. 16, No. 172 Cileunyi</p>
    </aside>
    <nav class="text-white">
        <h6 class="footer-title">Services</h6>
        <a class="link link-hover">Branding</a>
        <a class="link link-hover">Design</a>
        <a class="link link-hover">Marketing</a>
        <a class="link link-hover">Advertisement</a>
    </nav>
    <nav class="text-white">
        <h6 class="footer-title">Company</h6>
        <a class="link link-hover">About us</a>
        <a class="link link-hover">Contact</a>
        <a class="link link-hover">Jobs</a>
        <a class="link link-hover">Press kit</a>
    </nav>
    
</footer>
<footer class="footer footer-center p-2 bg-base-300 text-base-content">
    <aside>
      <p>Copyright © 2024 - All right reserved by ACME Industries Ltd</p>
    </aside>
  </footer>
<?php /**PATH C:\Users\eherd\OneDrive\Documents\Project\kta\resources\views/landing/components/footer/Footer.blade.php ENDPATH**/ ?>