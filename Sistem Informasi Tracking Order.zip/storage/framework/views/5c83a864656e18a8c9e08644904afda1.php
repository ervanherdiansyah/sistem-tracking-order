<div class=""  data-aos="fade-left" data-aos-duration="800">
<div class="p-2 bg-[#86B6F6] rounded-full shadow-md shadow-[#176B87] overflow-hidden w-[48px] hover:w-[170px] transition-all duration-500">
    <div class="flex items-center gap-2"> 
        <img src="assets/icons/whatsapp.png" alt="" class="h-8 w-8">
        <p class="text-white">089786676767</p>
    </div>
</div>
</div>
<?php /**PATH C:\Users\eherd\OneDrive\Documents\Project\web_ppdb\resources\views/landing/components/stiky/Stiky.blade.php ENDPATH**/ ?>