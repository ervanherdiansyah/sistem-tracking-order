<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('assets')); ?>/img/tasqira.webp">
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/img/tasqira.webp')); ?>">
    <title>
        <?php echo $__env->yieldContent('title'); ?>
    </title>
    <?php echo $__env->yieldContent('chartjs'); ?>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
    <!-- Nucleo Icons -->
    <link href="<?php echo e(asset('argon')); ?>/assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="<?php echo e(asset('argon')); ?>/assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- Font Awesome Icons -->
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link href="<?php echo e(asset('argon')); ?>/assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- CSS Files -->
    <link id="pagestyle" href="<?php echo e(asset('argon')); ?>/assets/css/argon-dashboard.css?v=2.0.4" rel="stylesheet" />
    <!-- Tautkan file CSS DataTables -->
    <?php echo $__env->yieldContent('css'); ?>


</head>

<body class="g-sidenav-show bg-gray-100">
    <?php if(Request::is('owner/profile*')): ?>
        <div class="position-absolute w-100 min-height-300 top-0">
            <span class="mask bg-danger opacity-10"></span>
        </div>
    <?php else: ?>
        <div class="min-height-300 bg-danger position-absolute w-100"></div>
    <?php endif; ?>
    <?php echo $__env->make('src.component.owner.sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(Request::is('owner/profile*')): ?>
        <div class="main-content position-relative max-height-vh-100 h-100">
            

            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    <?php else: ?>
        <main class="main-content position-relative border-radius-lg ">
            <!-- Navbar -->
            <?php echo $__env->make('src.component.owner.navbar.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End Navbar -->
            <!-- Content -->
            <?php echo $__env->yieldContent('content'); ?>
            <!-- End Content -->
            <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </main>
    <?php endif; ?>


    <?php echo $__env->make('src.component.owner.plugins.plugin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://cdn.ckeditor.com/ckeditor5/34.0.0/classic/ckeditor.js"></script>

    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('argon')); ?>/assets/js/core/popper.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/assets/js/core/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/assets/js/plugins/smooth-scrollbar.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/assets/js/plugins/chartjs.min.js"></script>
    <?php echo $__env->yieldPushContent('chart'); ?>
    <?php echo $__env->yieldPushContent('chartjs'); ?>
    <?php echo $__env->yieldPushContent('chartLine'); ?>
    <script>
        var win = navigator.platform.indexOf('Win') > -1;
        if (win && document.querySelector('#sidenav-scrollbar')) {
            var options = {
                damping: '0.5'
            }
            Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
        }
    </script>
    <!-- Github buttons -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="<?php echo e(asset('argon')); ?>/assets/js/argon-dashboard.min.js?v=2.0.4"></script>
    <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html>
<?php /**PATH C:\Users\eherd\OneDrive\Documents\Project\Sistem Informasi Tracking Order\resources\views/src/layouts/owner/layout.blade.php ENDPATH**/ ?>