<aside class="sidenav bg-white navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-4 "
    id="sidenav-main">
    <div class="sidenav-header">
        <i class="fas fa-times p-3 cursor-pointer text-secondary opacity-5 position-absolute end-0 top-0 d-none d-xl-none"
            aria-hidden="true" id="iconSidenav"></i>
        <?php if(isset(Auth::user()->foto) != null): ?>
            <a class="navbar-brand m-0" href=" <?php echo e(url('/dashboard/home')); ?>">
                <img src="<?php echo e(asset('storage/' . Auth::user()->foto)); ?>" class="navbar-brand-img h-100" alt="main_logo">
                <span class="ms-1 font-weight-bold"><?php echo e(Auth::user()->name); ?></span>
            </a>
        <?php else: ?>
            <a class="navbar-brand m-0" href=" <?php echo e(url('/dashboard/home')); ?>">
                <img src="<?php echo e(asset('argon')); ?>/assets/img/foto.png" class="navbar-brand-img h-100" alt="main_logo">
                <span class="ms-1 font-weight-bold"><?php echo e(Auth::user()->name); ?></span>
            </a>
        <?php endif; ?>
    </div>
    <hr class="horizontal dark mt-0">
    <div class="collapse navbar-collapse  w-auto " id="sidenav-collapse-main">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('dashboard/home') ? 'active' : ''); ?>"
                    href="<?php echo e(url('/dashboard/home')); ?>">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="ni ni-tv-2 text-primary text-sm opacity-10"></i>
                    </div>
                    <span class="nav-link-text ms-1">Dashboard </span>
                </a>
            </li>

            <li class="nav-item mt-3">
                <h6 class="ps-4 ms-2 text-uppercase text-xs font-weight-bolder opacity-6">Data Pendaftaran</h6>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('dashboard/pendaftaran') ? 'active' : ''); ?>"
                    href="<?php echo e(url('/dashboard/pendaftaran')); ?>">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="fa fa-book text-info text-sm opacity-10" aria-hidden="true"></i>
                    </div>
                    <span class="nav-link-text ms-1">Semua Data</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('dashboard/pengurus') ? 'active' : ''); ?>"
                    href="<?php echo e(url('/dashboard/pengurus')); ?>">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="fa fa-book text-info text-sm opacity-10" aria-hidden="true"></i>
                    </div>
                    <span class="nav-link-text ms-1">Data Pengurus</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('dashboard/peserta') ? 'active' : ''); ?>"
                    href="<?php echo e(url('/dashboard/peserta')); ?>">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="fa fa-book text-info text-sm opacity-10" aria-hidden="true"></i>
                    </div>
                    <span class="nav-link-text ms-1">Data Peserta</span>
                </a>
            </li>
            <li class="nav-item mt-3">
                <h6 class="ps-4 ms-2 text-uppercase text-xs font-weight-bolder opacity-6">Data Smile
                </h6>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('dashboard/pendaftaran-smile') ? 'active' : ''); ?>"
                    href="<?php echo e(url('/dashboard/pendaftaran-smile')); ?>">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="fa fa-book text-info text-sm opacity-10" aria-hidden="true"></i>
                    </div>
                    <span class="nav-link-text ms-1">Data Pendaftaran Smile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('dashboard/pembayaran-smile') ? 'active' : ''); ?>"
                    href="<?php echo e(url('/dashboard/pembayaran-smile')); ?>">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="fa fa-book text-info text-sm opacity-10" aria-hidden="true"></i>
                    </div>
                    <span class="nav-link-text ms-1">Data Pembayaran Smile</span>
                </a>
            </li>
            <li class="nav-item mt-3">
                <h6 class="ps-4 ms-2 text-uppercase text-xs font-weight-bolder opacity-6">Data Pembayaran
                </h6>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('dashboard/pembayaran') ? 'active' : ''); ?> "
                    href="<?php echo e(url('/dashboard/pembayaran')); ?>">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="ni ni-single-copy-04 text-danger text-sm opacity-10"></i>
                    </div>
                    <span class="nav-link-text ms-1">Semua Data Pembayaran</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('dashboard/pembayaran-paid') ? 'active' : ''); ?> "
                    href="<?php echo e(url('/dashboard/pembayaran-paid')); ?>">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="ni ni-single-copy-04 text-danger text-sm opacity-10"></i>
                    </div>
                    <span class="nav-link-text ms-1">Data Paid</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('dashboard/pembayaran-unpaid') ? 'active' : ''); ?> "
                    href="<?php echo e(url('/dashboard/pembayaran-unpaid')); ?>">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="ni ni-single-copy-04 text-danger text-sm opacity-10"></i>
                    </div>
                    <span class="nav-link-text ms-1">Data Unpaid</span>
                </a>
            </li>
            <li class="nav-item mt-3">
                <h6 class="ps-4 ms-2 text-uppercase text-xs font-weight-bolder opacity-6">Data User Account
                </h6>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('dashboard/account') ? 'active' : ''); ?>"
                    href="<?php echo e(url('/dashboard/account')); ?>">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="fa fa-users text-warning text-sm opacity-10" aria-hidden="true"></i>
                    </div>
                    <span class="nav-link-text ms-1">User Account</span>
                </a>
            </li>
            <li class="nav-item mt-3">
                <h6 class="ps-4 ms-2 text-uppercase text-xs font-weight-bolder opacity-6">Setting</h6>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('dashboard/profile') ? 'active' : ''); ?>"
                    href="<?php echo e(url('/dashboard/profile')); ?>">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="fa fa-user text-success text-sm opacity-10" aria-hidden="true"></i>
                    </div>
                    <span class="nav-link-text ms-1">Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->is('dashboard/changepassword') ? 'active' : ''); ?>"
                    href="<?php echo e(url('/dashboard/changepassword')); ?>">
                    <div
                        class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                        <i class="fa fa-cogs text-primary text-sm opacity-10"></i>
                    </div>
                    <span class="nav-link-text ms-1">Change Password</span>
                </a>
            </li>
            
        </ul>
    </div>
    <div class="sidenav-footer mx-3 ">
        <div class="card card-plain shadow-none" id="sidenavCard">
            <img class="w-50 mx-auto" src="<?php echo e(asset('assets/img/logo-fojb.png')); ?>" alt="sidebar_illustration">
            <div class="card-body text-center p-3 w-100 pt-0">
                <div class="docs-info">
                    <h6 class="mb-0">WEBSITE OPREC ANGGOTA</h6>
                    
                </div>
            </div>
        </div>
        
        <a class="btn btn-danger btn-sm mb-0 w-100" href="<?php echo e(route('logout')); ?>" type="button">Logout</a>
    </div>
</aside>
<?php /**PATH C:\Users\eherd\OneDrive\Documents\Project\kta\resources\views/dashboard/component/sidebar/sidebar.blade.php ENDPATH**/ ?>