<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SMK BANDUNG TIMUR</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <!-- Tambahkan link ke CSS Anda -->
    
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@chakra-ui/css-reset" rel="stylesheet">
    




</head>

<body>
    <div class="flex justify-center bg-[#F5F5F5] ">
        <div class="max-w-7xl w-[1280px]">
            <div class="w-[1280px] fixed top-0  z-[999]">
                <?php echo $__env->make('landing.components.navbar.Navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="z-10">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <div>
                <?php echo $__env->make('landing.components.footer.Footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <div class="fixed bottom-10 right-10 ">
                <?php echo $__env->make('landing.components.stiky.Stiky', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>

    <!-- Tambahkan link ke JavaScript Anda -->
    
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>
    
    <script>
        AOS.init();
    </script>
</body>

</html>
<?php /**PATH C:\Users\eherd\OneDrive\Documents\Project\web_ppdb\resources\views/landing/layouts/Layout.blade.php ENDPATH**/ ?>