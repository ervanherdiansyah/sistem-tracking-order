
<?php $__env->startSection('title', 'Pendaftaran'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <div class="row mt-4">
            <div class="col-lg-12 mb-lg-0 mb-4">
                <div class="card">
                    <div class="card-header pb-0">
                        <div class="d-flex align-items-center">
                            <p class="mb-0">Pendaftaran Smile</p>
                            <?php if($pendaftaran != null): ?>
                                <button type="button" class="btn btn-primary btn-sm ms-auto" data-bs-toggle="modal"
                                    data-bs-target="#update">
                                    Edit
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if($pendaftaran == null): ?>
                            <form action="<?php echo e(url('/peserta/pendaftaran/create')); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Nama
                                                Lengkap</label>
                                            <input name="nama_lengkap" type="text" class="form-control"
                                                placeholder="Nama Lengkap" aria-label="Name"
                                                value="<?php echo e(old('nama_lengkap')); ?>">
                                            <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Tanggal
                                                Lahir</label>
                                            <input name="tanggal_lahir" type="date" class="form-control"
                                                value="<?php echo e(old('tanggal_lahir')); ?>">
                                            <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">No
                                                Hp</label>
                                            <input name="hp" placeholder="No Hp" class="form-control" type="text"
                                                value="<?php echo e(old('hp')); ?>">
                                            <?php $__errorArgs = ['hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Email</label>
                                            <input name="email" placeholder="Email" class="form-control" type="email"
                                                value="<?php echo e(old('email')); ?>">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Alamat</label>
                                            <textarea name="alamat" id="" class="form-control"><?php echo e(old('alamat')); ?></textarea>
                                            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Asal
                                                sekolah</label>
                                            <input name="asal_sekolah" placeholder="Asal Sekolah" class="form-control"
                                                type="text" value="<?php echo e(old('asal_sekolah')); ?>">
                                            <?php $__errorArgs = ['asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Kelas</label>
                                            <select name="kelas" id="" class="form-control form-select">
                                                <option value="">Pilih</option>
                                                <option value="X" <?php if(old('kelas') == 'X'): ?> selected <?php endif; ?>>
                                                    X
                                                </option>
                                                <option value="XI" <?php if(old('kelas') == 'XI'): ?> selected <?php endif; ?>>
                                                    XI
                                                </option>
                                                <option value="XII" <?php if(old('kelas') == 'XII'): ?> selected <?php endif; ?>>
                                                    XII
                                                </option>
                                            </select>
                                            <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Kota atau
                                                Kabupaten Sekolah</label>
                                            <select name="alamat_asal_sekolah" id="kota"
                                                class="form-control form-select">
                                                <option value="">Pilih Kab/Kota</option>
                                            </select>
                                            <?php $__errorArgs = ['alamat_asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Nama Ibu
                                                Kandung</label>
                                            <input name="nama_ibu_kandung" type="text" class="form-control"
                                                value="<?php echo e(old('nama_ibu_kandung')); ?>">
                                            <?php $__errorArgs = ['nama_ibu_kandung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Nomor Induk
                                                Penduduk</label>
                                            <input name="nik" placeholder="nik" class="form-control" type="text"
                                                value="<?php echo e(old('nik')); ?>">
                                            <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Nomor Kartu
                                                Keluarga</label>
                                            <input name="no_kk" placeholder="no_kk" class="form-control"
                                                type="text" value="<?php echo e(old('no_kk')); ?>">
                                            <?php $__errorArgs = ['no_kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Jurusan Pilihan
                                                1</label>
                                            <select name="jurusan1" id="" class="form-control form-select">
                                                <option value="">Pilih</option>
                                                <option value="S1 Teknik Telekomunikasi"
                                                    <?php if(old('jurusan1') == 'S1 Teknik Telekomunikasi'): ?> selected <?php endif; ?>>
                                                    S1 Teknik Telekomunikasi
                                                </option>
                                                <option value="S1 Teknik Elektro"
                                                    <?php if(old('jurusan1') == 'S1 Teknik Elektro'): ?> selected <?php endif; ?>>
                                                    S1 Teknik Elektro
                                                </option>
                                                <option value="S1 Smart Science & Technology"
                                                    <?php if(old('jurusan1') == 'S1 Smart Science & Technology'): ?> selected <?php endif; ?>>
                                                    S1 Smart Science & Technology
                                                </option>
                                                <option value="S1 Teknik Komputer"
                                                    <?php if(old('jurusan1') == 'S1 Teknik Komputer'): ?> selected <?php endif; ?>>
                                                    S1 Teknik Komputer
                                                </option>
                                                <option value="S1 Teknik Biomedis"
                                                    <?php if(old('jurusan1') == 'S1 Teknik Biomedis'): ?> selected <?php endif; ?>>
                                                    S1 Teknik Biomedis
                                                </option>
                                                <option value="S1 Electrical Energy Engineering"
                                                    <?php if(old('jurusan1') == 'S1 Electrical Energy Engineering'): ?> selected <?php endif; ?>>
                                                    S1 Electrical Energy Engineering
                                                </option>
                                                <option value="S1 Informatika"
                                                    <?php if(old('jurusan1') == 'S1 Informatika'): ?> selected <?php endif; ?>>
                                                    S1 Informatika
                                                </option>
                                                <option value="S1 Data Sains"
                                                    <?php if(old('jurusan1') == 'S1 Data Sains'): ?> selected <?php endif; ?>>
                                                    S1 Data Sains
                                                </option>
                                                <option value="S1 Teknologi Informasi"
                                                    <?php if(old('jurusan1') == 'S1 Teknologi Informasi'): ?> selected <?php endif; ?>>
                                                    S1 Teknologi Informasi
                                                </option>
                                                <option value="S1 Rekayasa Perangkat Lunak"
                                                    <?php if(old('jurusan1') == 'S1 Rekayasa Perangkat Lunak'): ?> selected <?php endif; ?>>
                                                    S1 Rekayasa Perangkat Lunak
                                                </option>
                                                <option value="S1 Teknik Industri"
                                                    <?php if(old('jurusan1') == 'S1 Teknik Industri'): ?> selected <?php endif; ?>>
                                                    S1 Teknik Industri
                                                </option>
                                                <option value="S1 Sistem Informasi"
                                                    <?php if(old('jurusan1') == 'S1 Sistem Informasi'): ?> selected <?php endif; ?>>
                                                    S1 Sistem Informasi
                                                </option>
                                                <option value="S1 Digital Supply Chain"
                                                    <?php if(old('jurusan1') == 'S1 Digital Supply Chain'): ?> selected <?php endif; ?>>
                                                    S1 Digital Supply Chain
                                                </option>
                                                <option value="S1 Manajemen Rekayasa"
                                                    <?php if(old('jurusan1') == 'S1 Manajemen Rekayasa'): ?> selected <?php endif; ?>>
                                                    S1 Manajemen Rekayasa
                                                </option>
                                                <option value="S1 Ilmu Komunikasi"
                                                    <?php if(old('jurusan1') == 'S1 Ilmu Komunikasi'): ?> selected <?php endif; ?>>
                                                    S1 Ilmu Komunikasi
                                                </option>
                                                <option value="S1 Manajemen Bisnis Telekomunikasi & Informatika (MBTI)"
                                                    <?php if(old('jurusan1') == 'S1 Manajemen Bisnis Telekomunikasi & Informatika (MBTI)'): ?> selected <?php endif; ?>>
                                                    S1 Manajemen Bisnis Telekomunikasi & Informatika (MBTI)
                                                </option>
                                                <option value="S1 Akuntansi"
                                                    <?php if(old('jurusan1') == 'S1 Akuntansi'): ?> selected <?php endif; ?>>
                                                    S1 Akuntansi
                                                </option>
                                                <option value="S1 Administrasi Bisnis"
                                                    <?php if(old('jurusan1') == 'S1 Administrasi Bisnis'): ?> selected <?php endif; ?>>
                                                    S1 Administrasi Bisnis
                                                </option>
                                                <option value="S1 Manajemen Bisnis Rekreasi (Leisure Management)"
                                                    <?php if(old('jurusan1') == 'S1 Manajemen Bisnis Rekreasi (Leisure Management)'): ?> selected <?php endif; ?>>
                                                    S1 Manajemen Bisnis Rekreasi (Leisure Management)
                                                </option>
                                                <option value="S1 Digital Bisnis"
                                                    <?php if(old('jurusan1') == 'S1 Digital Bisnis'): ?> selected <?php endif; ?>>
                                                    S1 Digital Bisnis
                                                </option>
                                                <option value="S1 Digital Public Relation"
                                                    <?php if(old('jurusan1') == 'S1 Digital Public Relation'): ?> selected <?php endif; ?>>
                                                    S1 Digital Public Relation
                                                </option>
                                                <option value="S1 Digital Content Broadcasting"
                                                    <?php if(old('jurusan1') == 'S1 Digital Content Broadcasting'): ?> selected <?php endif; ?>>
                                                    S1 Digital Content Broadcasting
                                                </option>
                                                <option value="S1 Psikologi"
                                                    <?php if(old('jurusan1') == 'S1 Psikologi'): ?> selected <?php endif; ?>>
                                                    S1 Psikologi
                                                </option>
                                                <option value="S1 Desain Komunikasi Visual"
                                                    <?php if(old('jurusan1') == 'S1 Desain Komunikasi Visual'): ?> selected <?php endif; ?>>
                                                    S1 Desain Komunikasi Visual
                                                </option>
                                                <option value="S1 Desain Produk & Inovasi"
                                                    <?php if(old('jurusan1') == 'S1 Desain Produk & Inovasi'): ?> selected <?php endif; ?>>
                                                    S1 Desain Produk & Inovasi
                                                </option>
                                                <option value="S1 Desain Interior"
                                                    <?php if(old('jurusan1') == 'S1 Desain Interior'): ?> selected <?php endif; ?>>
                                                    S1 Desain Interior
                                                </option>
                                                <option value="S1 Creative Arts (Intermedia Visual Arts)"
                                                    <?php if(old('jurusan1') == 'S1 Creative Arts (Intermedia Visual Arts)'): ?> selected <?php endif; ?>>
                                                    S1 Creative Arts (Intermedia Visual Arts)
                                                </option>
                                                <option value="S1 Kriya Fashion & Textile Design"
                                                    <?php if(old('jurusan1') == 'S1 Kriya Fashion & Textile Design'): ?> selected <?php endif; ?>>
                                                    S1 Kriya Fashion & Textile Design
                                                </option>
                                                <option value="S1 Film & Animasi"
                                                    <?php if(old('jurusan1') == 'S1 Film & Animasi'): ?> selected <?php endif; ?>>
                                                    S1 Film & Animasi
                                                </option>
                                                <option value="D3 Teknik Telekomunikasi (Digital Connectivity)"
                                                    <?php if(old('jurusan1') == 'D3 Teknik Telekomunikasi (Digital Connectivity)'): ?> selected <?php endif; ?>>
                                                    D3 Teknik Telekomunikasi (Digital Connectivity)
                                                </option>
                                                <option value="D3 Teknik Informatika"
                                                    <?php if(old('jurusan1') == 'D3 Teknik Informatika'): ?> selected <?php endif; ?>>
                                                    D3 Teknik Informatika
                                                </option>
                                                <option value="D3 Teknik Kompute"
                                                    <?php if(old('jurusan1') == 'D3 Teknik Kompute'): ?> selected <?php endif; ?>>
                                                    D3 Teknik Kompute
                                                </option>
                                                <option value="D3 Sistem Informasi"
                                                    <?php if(old('jurusan1') == 'D3 Sistem Informasi'): ?> selected <?php endif; ?>>
                                                    D3 Sistem Informasi
                                                </option>
                                                <option value="D3 Digital Accounting (Sistem Informasi Akuntansi)"
                                                    <?php if(old('jurusan1') == 'D3 Digital Accounting (Sistem Informasi Akuntansi)'): ?> selected <?php endif; ?>>
                                                    D3 Digital Accounting (Sistem Informasi Akuntansi)
                                                </option>
                                                <option value="D3 Hospitality & Culinary Art"
                                                    <?php if(old('jurusan1') == 'D3 Hospitality & Culinary Art'): ?> selected <?php endif; ?>>
                                                    D3 Hospitality & Culinary Art
                                                </option>
                                                <option value="D3 Digital Marketing"
                                                    <?php if(old('jurusan1') == 'D3 Digital Marketing'): ?> selected <?php endif; ?>>
                                                    D3 Digital Marketing
                                                </option>
                                                <option value="S1 Terapan Digital Creative Multimedia (DCM)"
                                                    <?php if(old('jurusan1') == 'S1 Terapan Digital Creative Multimedia (DCM)'): ?> selected <?php endif; ?>>
                                                    S1 Terapan Digital Creative Multimedia (DCM)
                                                </option>
                                                <option value="S1 Terapan Smart City Information System"
                                                    <?php if(old('jurusan1') == 'S1 Terapan Smart City Information System'): ?> selected <?php endif; ?>>
                                                    S1 Terapan Smart City Information System
                                                </option>
                                            </select>
                                            <?php $__errorArgs = ['jurusan1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Jurusan Pilihan
                                                2</label>
                                            <select name="jurusan2" id="" class="form-control form-select">
                                                <option value="">Pilih</option>
                                                <option value="S1 Teknik Telekomunikasi"
                                                    <?php if(old('jurusan2') == 'S1 Teknik Telekomunikasi'): ?> selected <?php endif; ?>>
                                                    S1 Teknik Telekomunikasi
                                                </option>
                                                <option value="S1 Teknik Elektro"
                                                    <?php if(old('jurusan2') == 'S1 Teknik Elektro'): ?> selected <?php endif; ?>>
                                                    S1 Teknik Elektro
                                                </option>
                                                <option value="S1 Smart Science & Technology"
                                                    <?php if(old('jurusan2') == 'S1 Smart Science & Technology'): ?> selected <?php endif; ?>>
                                                    S1 Smart Science & Technology
                                                </option>
                                                <option value="S1 Teknik Komputer"
                                                    <?php if(old('jurusan2') == 'S1 Teknik Komputer'): ?> selected <?php endif; ?>>
                                                    S1 Teknik Komputer
                                                </option>
                                                <option value="S1 Teknik Biomedis"
                                                    <?php if(old('jurusan2') == 'S1 Teknik Biomedis'): ?> selected <?php endif; ?>>
                                                    S1 Teknik Biomedis
                                                </option>
                                                <option value="S1 Electrical Energy Engineering"
                                                    <?php if(old('jurusan2') == 'S1 Electrical Energy Engineering'): ?> selected <?php endif; ?>>
                                                    S1 Electrical Energy Engineering
                                                </option>
                                                <option value="S1 Informatika"
                                                    <?php if(old('jurusan2') == 'S1 Informatika'): ?> selected <?php endif; ?>>
                                                    S1 Informatika
                                                </option>
                                                <option value="S1 Data Sains"
                                                    <?php if(old('jurusan2') == 'S1 Data Sains'): ?> selected <?php endif; ?>>
                                                    S1 Data Sains
                                                </option>
                                                <option value="S1 Teknologi Informasi"
                                                    <?php if(old('jurusan2') == 'S1 Teknologi Informasi'): ?> selected <?php endif; ?>>
                                                    S1 Teknologi Informasi
                                                </option>
                                                <option value="S1 Rekayasa Perangkat Lunak"
                                                    <?php if(old('jurusan2') == 'S1 Rekayasa Perangkat Lunak'): ?> selected <?php endif; ?>>
                                                    S1 Rekayasa Perangkat Lunak
                                                </option>
                                                <option value="S1 Teknik Industri"
                                                    <?php if(old('jurusan2') == 'S1 Teknik Industri'): ?> selected <?php endif; ?>>
                                                    S1 Teknik Industri
                                                </option>
                                                <option value="S1 Sistem Informasi"
                                                    <?php if(old('jurusan2') == 'S1 Sistem Informasi'): ?> selected <?php endif; ?>>
                                                    S1 Sistem Informasi
                                                </option>
                                                <option value="S1 Digital Supply Chain"
                                                    <?php if(old('jurusan2') == 'S1 Digital Supply Chain'): ?> selected <?php endif; ?>>
                                                    S1 Digital Supply Chain
                                                </option>
                                                <option value="S1 Manajemen Rekayasa"
                                                    <?php if(old('jurusan2') == 'S1 Manajemen Rekayasa'): ?> selected <?php endif; ?>>
                                                    S1 Manajemen Rekayasa
                                                </option>
                                                <option value="S1 Ilmu Komunikasi"
                                                    <?php if(old('jurusan2') == 'S1 Ilmu Komunikasi'): ?> selected <?php endif; ?>>
                                                    S1 Ilmu Komunikasi
                                                </option>
                                                <option value="S1 Manajemen Bisnis Telekomunikasi & Informatika (MBTI)"
                                                    <?php if(old('jurusan2') == 'S1 Manajemen Bisnis Telekomunikasi & Informatika (MBTI)'): ?> selected <?php endif; ?>>
                                                    S1 Manajemen Bisnis Telekomunikasi & Informatika (MBTI)
                                                </option>
                                                <option value="S1 Akuntansi"
                                                    <?php if(old('jurusan2') == 'S1 Akuntansi'): ?> selected <?php endif; ?>>
                                                    S1 Akuntansi
                                                </option>
                                                <option value="S1 Administrasi Bisnis"
                                                    <?php if(old('jurusan2') == 'S1 Administrasi Bisnis'): ?> selected <?php endif; ?>>
                                                    S1 Administrasi Bisnis
                                                </option>
                                                <option value="S1 Manajemen Bisnis Rekreasi (Leisure Management)"
                                                    <?php if(old('jurusan2') == 'S1 Manajemen Bisnis Rekreasi (Leisure Management)'): ?> selected <?php endif; ?>>
                                                    S1 Manajemen Bisnis Rekreasi (Leisure Management)
                                                </option>
                                                <option value="S1 Digital Bisnis"
                                                    <?php if(old('jurusan2') == 'S1 Digital Bisnis'): ?> selected <?php endif; ?>>
                                                    S1 Digital Bisnis
                                                </option>
                                                <option value="S1 Digital Public Relation"
                                                    <?php if(old('jurusan2') == 'S1 Digital Public Relation'): ?> selected <?php endif; ?>>
                                                    S1 Digital Public Relation
                                                </option>
                                                <option value="S1 Digital Content Broadcasting"
                                                    <?php if(old('jurusan2') == 'S1 Digital Content Broadcasting'): ?> selected <?php endif; ?>>
                                                    S1 Digital Content Broadcasting
                                                </option>
                                                <option value="S1 Psikologi"
                                                    <?php if(old('jurusan2') == 'S1 Psikologi'): ?> selected <?php endif; ?>>
                                                    S1 Psikologi
                                                </option>
                                                <option value="S1 Desain Komunikasi Visual"
                                                    <?php if(old('jurusan2') == 'S1 Desain Komunikasi Visual'): ?> selected <?php endif; ?>>
                                                    S1 Desain Komunikasi Visual
                                                </option>
                                                <option value="S1 Desain Produk & Inovasi"
                                                    <?php if(old('jurusan2') == 'S1 Desain Produk & Inovasi'): ?> selected <?php endif; ?>>
                                                    S1 Desain Produk & Inovasi
                                                </option>
                                                <option value="S1 Desain Interior"
                                                    <?php if(old('jurusan2') == 'S1 Desain Interior'): ?> selected <?php endif; ?>>
                                                    S1 Desain Interior
                                                </option>
                                                <option value="S1 Creative Arts (Intermedia Visual Arts)"
                                                    <?php if(old('jurusan2') == 'S1 Creative Arts (Intermedia Visual Arts)'): ?> selected <?php endif; ?>>
                                                    S1 Creative Arts (Intermedia Visual Arts)
                                                </option>
                                                <option value="S1 Kriya Fashion & Textile Design"
                                                    <?php if(old('jurusan2') == 'S1 Kriya Fashion & Textile Design'): ?> selected <?php endif; ?>>
                                                    S1 Kriya Fashion & Textile Design
                                                </option>
                                                <option value="S1 Film & Animasi"
                                                    <?php if(old('jurusan2') == 'S1 Film & Animasi'): ?> selected <?php endif; ?>>
                                                    S1 Film & Animasi
                                                </option>
                                                <option value="D3 Teknik Telekomunikasi (Digital Connectivity)"
                                                    <?php if(old('jurusan2') == 'D3 Teknik Telekomunikasi (Digital Connectivity)'): ?> selected <?php endif; ?>>
                                                    D3 Teknik Telekomunikasi (Digital Connectivity)
                                                </option>
                                                <option value="D3 Teknik Informatika"
                                                    <?php if(old('jurusan2') == 'D3 Teknik Informatika'): ?> selected <?php endif; ?>>
                                                    D3 Teknik Informatika
                                                </option>
                                                <option value="D3 Teknik Kompute"
                                                    <?php if(old('jurusan2') == 'D3 Teknik Kompute'): ?> selected <?php endif; ?>>
                                                    D3 Teknik Kompute
                                                </option>
                                                <option value="D3 Sistem Informasi"
                                                    <?php if(old('jurusan2') == 'D3 Sistem Informasi'): ?> selected <?php endif; ?>>
                                                    D3 Sistem Informasi
                                                </option>
                                                <option value="D3 Digital Accounting (Sistem Informasi Akuntansi)"
                                                    <?php if(old('jurusan2') == 'D3 Digital Accounting (Sistem Informasi Akuntansi)'): ?> selected <?php endif; ?>>
                                                    D3 Digital Accounting (Sistem Informasi Akuntansi)
                                                </option>
                                                <option value="D3 Hospitality & Culinary Art"
                                                    <?php if(old('jurusan2') == 'D3 Hospitality & Culinary Art'): ?> selected <?php endif; ?>>
                                                    D3 Hospitality & Culinary Art
                                                </option>
                                                <option value="D3 Digital Marketing"
                                                    <?php if(old('jurusan2') == 'D3 Digital Marketing'): ?> selected <?php endif; ?>>
                                                    D3 Digital Marketing
                                                </option>
                                                <option value="S1 Terapan Digital Creative Multimedia (DCM)"
                                                    <?php if(old('jurusan2') == 'S1 Terapan Digital Creative Multimedia (DCM)'): ?> selected <?php endif; ?>>
                                                    S1 Terapan Digital Creative Multimedia (DCM)
                                                </option>
                                                <option value="S1 Terapan Smart City Information System"
                                                    <?php if(old('jurusan2') == 'S1 Terapan Smart City Information System'): ?> selected <?php endif; ?>>
                                                    S1 Terapan Smart City Information System
                                                </option>
                                            </select>
                                            <?php $__errorArgs = ['jurusan2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn bg-gradient-dark w-100 my-4 mb-2">Submit</button>
                                </div>
                            </form>
                        <?php else: ?>
                            <div class="card">
                                <div class="card-body">
                                    <div>
                                        <span>
                                            <h5>Highlight Rangkaian Acara:</h5>
                                            <ul>
                                                <li>Talkshow</li>
                                                <li>Trial Class</li>
                                                <li>Campus Tour</li>
                                                <li>Music Performance</li>
                                                <li>Pelantikan & Pengukuhan FOJB Gen 12</li>
                                                <li>Menyambut Hari Indonesia Menabung</li>
                                            </ul>
                                            <h5>Benefit:</h5>
                                            <ul>
                                                <li>Konsumsi</li>
                                                <li>Berpartisipasi pada rangkaian Hari Indonesia Menabung</li>
                                                <li>Mendapatkan rekening Bank BJB</li>
                                                <li>E-Certificate</li>
                                            </ul>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6" style="text-align: center;">
                                            <h5>Klik untuk Membayar</h5>
                                            <h3><a href="https://app.midtrans.com/payment-links/1721289061579"
                                                    class="btn btn-primary" target="_blank">Pembayaran</a></h3>
                                        </div>
                                        <div class="col-md-6">
                                            <form action="<?php echo e(url('/peserta/pendaftaran/uploadbuktipembayaran')); ?>"
                                                method="POST" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <h5>Upload Bukti Pembayaran</h5>
                                                <input name="bukti_pembayaran" class="form-control" type="file"
                                                    value="<?php echo e(old('bukti_pembayaran')); ?>">
                                                <?php $__errorArgs = ['bukti_pembayaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                <div style="padding-top: 5px">
                                                    <button type="submit" class="btn btn-primary">Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <form action="<?php echo e(url('/peserta/pendaftaran/update/' . $pendaftaran->id)); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Nama
                                                Lengkap</label>
                                            <input name="nama_lengkap" class="form-control" type="text"
                                                value="<?php echo e($pendaftaran->nama_lengkap ?? ''); ?> "
                                                <?php if(isset($pendaftaran) && $pendaftaran->nama_lengkap): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Tanggal
                                                Lahir</label>
                                            <input name="tanggal_lahir" class="form-control" type="text"
                                                value="<?php echo e($pendaftaran->tanggal_lahir ?? ''); ?> "
                                                <?php if(isset($pendaftaran) && $pendaftaran->tanggal_lahir): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Nomor
                                                Whatsapp</label>
                                            <input name="hp" class="form-control" type="text"
                                                value="<?php echo e($pendaftaran->hp ?? ''); ?>"
                                                <?php if(isset($pendaftaran) && $pendaftaran->hp): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Email</label>
                                            <input name="email" class="form-control" type="email"
                                                value="<?php echo e($pendaftaran->email ?? ''); ?>"
                                                <?php if(isset($pendaftaran) && $pendaftaran->email): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Alamat</label>
                                            <input name="alamat" class="form-control" type="text"
                                                value="<?php echo e($pendaftaran->alamat ?? ''); ?>"
                                                <?php if(isset($pendaftaran) && $pendaftaran->alamat): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Asal
                                                Sekolah</label>
                                            <input name="asal_sekolah" class="form-control" type="text"
                                                value="<?php echo e($pendaftaran->asal_sekolah ?? ''); ?>"
                                                <?php if(isset($pendaftaran) && $pendaftaran->asal_sekolah): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Kelas</label>
                                            <input name="tempat_lahir" class="form-control" type="text"
                                                value="<?php echo e($pendaftaran->kelas ?? ''); ?> "
                                                <?php if(isset($pendaftaran) && $pendaftaran->kelas): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Kota atau Kabupaten
                                                Sekolah</label>
                                            <input name="alamat_asal_sekolah" class="form-control" type="text"
                                                value="<?php echo e($pendaftaran->alamat_asal_sekolah ?? ''); ?>"
                                                <?php if(isset($pendaftaran) && $pendaftaran->alamat_asal_sekolah): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['alamat_asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Nama Ibu
                                                Kandung</label>
                                            <input name="nama_ibu_kandung" class="form-control" type="text"
                                                value="<?php echo e($pendaftaran->nama_ibu_kandung ?? ''); ?>"
                                                <?php if(isset($pendaftaran) && $pendaftaran->nama_ibu_kandung): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['nama_ibu_kandung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Nomor Induk
                                                Kependudukan</label>
                                            <input name="nik" class="form-control" type="text"
                                                value="<?php echo e($pendaftaran->nik ?? ''); ?>"
                                                <?php if(isset($pendaftaran) && $pendaftaran->nik): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Nomor Kartu
                                                Keluarga</label>
                                            <input name="no_kk" class="form-control" type="text"
                                                value="<?php echo e($pendaftaran->no_kk ?? ''); ?>"
                                                <?php if(isset($pendaftaran) && $pendaftaran->no_kk): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['no_kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Jurusan Pilihan
                                                1</label>
                                            <input name="jurusan1" class="form-control" type="text"
                                                value="<?php echo e($pendaftaran->jurusan1 ?? ''); ?>"
                                                <?php if(isset($pendaftaran) && $pendaftaran->jurusan1): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['jurusan1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Jurusan Pilihan
                                                2</label>
                                            <input name="jurusan2" class="form-control" type="text"
                                                value="<?php echo e($pendaftaran->jurusan2 ?? ''); ?>"
                                                <?php if(isset($pendaftaran) && $pendaftaran->jurusan2): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['jurusan2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <?php if(isset($pendaftaran)): ?>
            <div class="modal fade" id="update" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Update pendaftaran</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(url('/peserta/pendaftaran/update/' . $pendaftaran->id)); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Nama
                                                Lengkap</label>
                                            <input name="nama_lengkap" type="text" class="form-control"
                                                placeholder="Nama Lengkap" aria-label="Name"
                                                value="<?php echo e(old('nama_lengkap', $pendaftaran->nama_lengkap)); ?>">
                                            <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Tanggal
                                                Lahir</label>
                                            <input name="tanggal_lahir" type="date" class="form-control"
                                                value="<?php echo e(old('tanggal_lahir', $pendaftaran->tanggal_lahir)); ?>">
                                            <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">No Hp</label>
                                            <input name="hp" placeholder="No Hp" class="form-control"
                                                type="text" value="<?php echo e(old('hp', $pendaftaran->hp)); ?>">
                                            <?php $__errorArgs = ['hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Email</label>
                                            <input name="email" placeholder="Email" class="form-control"
                                                type="email" value="<?php echo e(old('email', $pendaftaran->email)); ?>">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Alamat</label>
                                            <textarea name="alamat" id="" class="form-control"><?php echo e(old('alamat', $pendaftaran->alamat)); ?></textarea>
                                            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Asal
                                                sekolah</label>
                                            <input name="asal_sekolah" placeholder="Asal Sekolah" class="form-control"
                                                type="text"
                                                value="<?php echo e(old('asal_sekolah', $pendaftaran->asal_sekolah)); ?>">
                                            <?php $__errorArgs = ['asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Kelas</label>
                                            <select name="kelas" id="" class="form-control form-select">
                                                <option value="">Pilih</option>
                                                <option value="X" <?php if(old('kelas', $pendaftaran->kelas) == 'X'): ?> selected <?php endif; ?>>
                                                    X
                                                </option>
                                                <option value="XI" <?php if(old('kelas', $pendaftaran->kelas) == 'XI'): ?> selected <?php endif; ?>>
                                                    XI
                                                </option>
                                                <option value="XII" <?php if(old('kelas', $pendaftaran->kelas) == 'XII'): ?> selected <?php endif; ?>>
                                                    XII
                                                </option>
                                            </select>
                                            <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Kota atau Kabupaten
                                                Sekolah</label>
                                            <select name="alamat_asal_sekolah" id="kotaa"
                                                class="form-control form-select"
                                                data-selected="<?php echo e($pendaftaran->alamat_asal_sekolah); ?>">
                                                <option value="">Pilih Kab/Kota</option>
                                            </select>
                                            <?php $__errorArgs = ['alamat_asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Nama Ibu
                                                Kandung</label>
                                            <input name="nama_ibu_kandung" type="text" class="form-control"
                                                value="<?php echo e(old('nama_ibu_kandung', $pendaftaran->nama_ibu_kandung)); ?>">
                                            <?php $__errorArgs = ['nama_ibu_kandung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Nomor Induk
                                                Kependudukan</label>
                                            <input name="nik" placeholder="nik" class="form-control" type="text"
                                                value="<?php echo e(old('nik', $pendaftaran->nik)); ?>">
                                            <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Nomor Kartu
                                                Keluarga</label>
                                            <input name="no_kk" placeholder="no_kk" class="form-control"
                                                type="text" value="<?php echo e(old('no_kk', $pendaftaran->no_kk)); ?>">
                                            <?php $__errorArgs = ['no_kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Jurusan Pilihan
                                                1</label>
                                            <select name="jurusan1" id="" class="form-control form-select">
                                                <option value="">Pilih</option>
                                                <option value="S1 Teknik Telekomunikasi"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Teknik Telekomunikasi'): ?> selected <?php endif; ?>>S1 Teknik
                                                    Telekomunikasi</option>
                                                <option value="S1 Teknik Elektro"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Teknik Elektro'): ?> selected <?php endif; ?>>S1 Teknik Elektro
                                                </option>
                                                <option value="S1 Smart Science & Technology"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Smart Science & Technology'): ?> selected <?php endif; ?>>S1 Smart Science &
                                                    Technology</option>
                                                <option value="S1 Teknik Komputer"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Teknik Komputer'): ?> selected <?php endif; ?>>S1 Teknik Komputer
                                                </option>
                                                <option value="S1 Teknik Biomedis"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Teknik Biomedis'): ?> selected <?php endif; ?>>S1 Teknik Biomedis
                                                </option>
                                                <option value="S1 Electrical Energy Engineering"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Electrical Energy Engineering'): ?> selected <?php endif; ?>>S1 Electrical
                                                    Energy Engineering</option>
                                                <option value="S1 Informatika"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Informatika'): ?> selected <?php endif; ?>>S1 Informatika
                                                </option>
                                                <option value="S1 Data Sains"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Data Sains'): ?> selected <?php endif; ?>>S1 Data Sains
                                                </option>
                                                <option value="S1 Teknologi Informasi"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Teknologi Informasi'): ?> selected <?php endif; ?>>S1 Teknologi
                                                    Informasi</option>
                                                <option value="S1 Rekayasa Perangkat Lunak"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Rekayasa Perangkat Lunak'): ?> selected <?php endif; ?>>S1 Rekayasa
                                                    Perangkat Lunak</option>
                                                <option value="S1 Teknik Industri"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Teknik Industri'): ?> selected <?php endif; ?>>S1 Teknik Industri
                                                </option>
                                                <option value="S1 Sistem Informasi"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Sistem Informasi'): ?> selected <?php endif; ?>>S1 Sistem
                                                    Informasi</option>
                                                <option value="S1 Digital Supply Chain"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Digital Supply Chain'): ?> selected <?php endif; ?>>S1 Digital Supply
                                                    Chain</option>
                                                <option value="S1 Manajemen Rekayasa"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Manajemen Rekayasa'): ?> selected <?php endif; ?>>S1 Manajemen
                                                    Rekayasa</option>
                                                <option value="S1 Ilmu Komunikasi"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Ilmu Komunikasi'): ?> selected <?php endif; ?>>S1 Ilmu Komunikasi
                                                </option>
                                                <option value="S1 Manajemen Bisnis Telekomunikasi & Informatika (MBTI)"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Manajemen Bisnis Telekomunikasi & Informatika (MBTI)'): ?> selected <?php endif; ?>>S1 Manajemen
                                                    Bisnis Telekomunikasi & Informatika (MBTI)</option>
                                                <option value="S1 Akuntansi"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Akuntansi'): ?> selected <?php endif; ?>>S1 Akuntansi
                                                </option>
                                                <option value="S1 Administrasi Bisnis"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Administrasi Bisnis'): ?> selected <?php endif; ?>>S1 Administrasi
                                                    Bisnis</option>
                                                <option value="S1 Manajemen Bisnis Rekreasi (Leisure Management)"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Manajemen Bisnis Rekreasi (Leisure Management)'): ?> selected <?php endif; ?>>S1 Manajemen
                                                    Bisnis Rekreasi (Leisure Management)</option>
                                                <option value="S1 Digital Bisnis"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Digital Bisnis'): ?> selected <?php endif; ?>>S1 Digital Bisnis
                                                </option>
                                                <option value="S1 Digital Public Relation"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Digital Public Relation'): ?> selected <?php endif; ?>>S1 Digital Public
                                                    Relation</option>
                                                <option value="S1 Digital Content Broadcasting"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Digital Content Broadcasting'): ?> selected <?php endif; ?>>S1 Digital Content
                                                    Broadcasting</option>
                                                <option value="S1 Psikologi"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Psikologi'): ?> selected <?php endif; ?>>S1 Psikologi
                                                </option>
                                                <option value="S1 Desain Komunikasi Visual"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Desain Komunikasi Visual'): ?> selected <?php endif; ?>>S1 Desain
                                                    Komunikasi Visual</option>
                                                <option value="S1 Desain Produk & Inovasi"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Desain Produk & Inovasi'): ?> selected <?php endif; ?>>S1 Desain Produk &
                                                    Inovasi</option>
                                                <option value="S1 Desain Interior"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Desain Interior'): ?> selected <?php endif; ?>>S1 Desain Interior
                                                </option>
                                                <option value="S1 Creative Arts (Intermedia Visual Arts)"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Creative Arts (Intermedia Visual Arts)'): ?> selected <?php endif; ?>>S1 Creative Arts
                                                    (Intermedia Visual Arts)</option>
                                                <option value="S1 Kriya Fashion & Textile Design"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Kriya Fashion & Textile Design'): ?> selected <?php endif; ?>>S1 Kriya Fashion &
                                                    Textile Design</option>
                                                <option value="S1 Film & Animasi"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'S1 Film & Animasi'): ?> selected <?php endif; ?>>S1 Film & Animasi
                                                </option>
                                                <option value="D3 Teknik Telekomunikasi (Digital Connectivity)"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'D3 Teknik Telekomunikasi (Digital Connectivity)'): ?> selected <?php endif; ?>>D3 Teknik
                                                    Telekomunikasi (Digital Connectivity)</option>
                                                <option value="D3 Teknik Informatika"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'D3 Teknik Informatika'): ?> selected <?php endif; ?>>D3 Teknik
                                                    Informatika</option>
                                                <option value="D3 Teknik Komputer"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'D3 Teknik Komputer'): ?> selected <?php endif; ?>>D3 Teknik Komputer
                                                </option>
                                                <option value="D3 Sistem Informasi"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'D3 Sistem Informasi'): ?> selected <?php endif; ?>>D3 Sistem
                                                    Informasi</option>
                                                <option value="D3 Digital Accounting (Sistem Informasi Akuntansi)"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'D3 Digital Accounting (Sistem Informasi Akuntansi)'): ?> selected <?php endif; ?>>D3 Digital
                                                    Accounting (Sistem Informasi Akuntansi)</option>
                                                <option value="D3 Hospitality & Culinary Art"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'D3 Hospitality & Culinary Art'): ?> selected <?php endif; ?>>D3 Hospitality &
                                                    Culinary Art</option>
                                                <option value="D3 Digital Marketing"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'D3 Digital Marketing'): ?> selected <?php endif; ?>>D3 Digital
                                                    Marketing</option>
                                                <option value="D3 Creative Multimedia"
                                                    <?php if(old('jurusan1', $pendaftaran->jurusan1) == 'D3 Creative Multimedia'): ?> selected <?php endif; ?>>D3 Creative
                                                    Multimedia</option>
                                            </select>
                                            <?php $__errorArgs = ['jurusan1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Jurusan Pilihan
                                                2</label>
                                            <select name="jurusan2" id="" class="form-control form-select">
                                                <option value="">Pilih</option>
                                                <option value="S1 Teknik Telekomunikasi"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Teknik Telekomunikasi'): ?> selected <?php endif; ?>>S1 Teknik
                                                    Telekomunikasi</option>
                                                <option value="S1 Teknik Elektro"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Teknik Elektro'): ?> selected <?php endif; ?>>S1 Teknik Elektro
                                                </option>
                                                <option value="S1 Smart Science & Technology"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Smart Science & Technology'): ?> selected <?php endif; ?>>S1 Smart Science &
                                                    Technology</option>
                                                <option value="S1 Teknik Komputer"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Teknik Komputer'): ?> selected <?php endif; ?>>S1 Teknik Komputer
                                                </option>
                                                <option value="S1 Teknik Biomedis"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Teknik Biomedis'): ?> selected <?php endif; ?>>S1 Teknik Biomedis
                                                </option>
                                                <option value="S1 Electrical Energy Engineering"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Electrical Energy Engineering'): ?> selected <?php endif; ?>>S1 Electrical
                                                    Energy Engineering</option>
                                                <option value="S1 Informatika"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Informatika'): ?> selected <?php endif; ?>>S1 Informatika
                                                </option>
                                                <option value="S1 Data Sains"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Data Sains'): ?> selected <?php endif; ?>>S1 Data Sains
                                                </option>
                                                <option value="S1 Teknologi Informasi"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Teknologi Informasi'): ?> selected <?php endif; ?>>S1 Teknologi
                                                    Informasi</option>
                                                <option value="S1 Rekayasa Perangkat Lunak"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Rekayasa Perangkat Lunak'): ?> selected <?php endif; ?>>S1 Rekayasa
                                                    Perangkat Lunak</option>
                                                <option value="S1 Teknik Industri"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Teknik Industri'): ?> selected <?php endif; ?>>S1 Teknik Industri
                                                </option>
                                                <option value="S1 Sistem Informasi"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Sistem Informasi'): ?> selected <?php endif; ?>>S1 Sistem
                                                    Informasi</option>
                                                <option value="S1 Digital Supply Chain"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Digital Supply Chain'): ?> selected <?php endif; ?>>S1 Digital Supply
                                                    Chain</option>
                                                <option value="S1 Manajemen Rekayasa"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Manajemen Rekayasa'): ?> selected <?php endif; ?>>S1 Manajemen
                                                    Rekayasa</option>
                                                <option value="S1 Ilmu Komunikasi"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Ilmu Komunikasi'): ?> selected <?php endif; ?>>S1 Ilmu Komunikasi
                                                </option>
                                                <option value="S1 Manajemen Bisnis Telekomunikasi & Informatika (MBTI)"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Manajemen Bisnis Telekomunikasi & Informatika (MBTI)'): ?> selected <?php endif; ?>>S1 Manajemen
                                                    Bisnis Telekomunikasi & Informatika (MBTI)</option>
                                                <option value="S1 Akuntansi"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Akuntansi'): ?> selected <?php endif; ?>>S1 Akuntansi
                                                </option>
                                                <option value="S1 Administrasi Bisnis"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Administrasi Bisnis'): ?> selected <?php endif; ?>>S1 Administrasi
                                                    Bisnis</option>
                                                <option value="S1 Manajemen Bisnis Rekreasi (Leisure Management)"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Manajemen Bisnis Rekreasi (Leisure Management)'): ?> selected <?php endif; ?>>S1 Manajemen
                                                    Bisnis Rekreasi (Leisure Management)</option>
                                                <option value="S1 Digital Bisnis"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Digital Bisnis'): ?> selected <?php endif; ?>>S1 Digital Bisnis
                                                </option>
                                                <option value="S1 Digital Public Relation"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Digital Public Relation'): ?> selected <?php endif; ?>>S1 Digital Public
                                                    Relation</option>
                                                <option value="S1 Digital Content Broadcasting"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Digital Content Broadcasting'): ?> selected <?php endif; ?>>S1 Digital Content
                                                    Broadcasting</option>
                                                <option value="S1 Psikologi"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Psikologi'): ?> selected <?php endif; ?>>S1 Psikologi
                                                </option>
                                                <option value="S1 Desain Komunikasi Visual"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Desain Komunikasi Visual'): ?> selected <?php endif; ?>>S1 Desain
                                                    Komunikasi Visual</option>
                                                <option value="S1 Desain Produk & Inovasi"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Desain Produk & Inovasi'): ?> selected <?php endif; ?>>S1 Desain Produk &
                                                    Inovasi</option>
                                                <option value="S1 Desain Interior"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Desain Interior'): ?> selected <?php endif; ?>>S1 Desain Interior
                                                </option>
                                                <option value="S1 Creative Arts (Intermedia Visual Arts)"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Creative Arts (Intermedia Visual Arts)'): ?> selected <?php endif; ?>>S1 Creative Arts
                                                    (Intermedia Visual Arts)</option>
                                                <option value="S1 Kriya Fashion & Textile Design"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Kriya Fashion & Textile Design'): ?> selected <?php endif; ?>>S1 Kriya Fashion &
                                                    Textile Design</option>
                                                <option value="S1 Film & Animasi"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'S1 Film & Animasi'): ?> selected <?php endif; ?>>S1 Film & Animasi
                                                </option>
                                                <option value="D3 Teknik Telekomunikasi (Digital Connectivity)"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'D3 Teknik Telekomunikasi (Digital Connectivity)'): ?> selected <?php endif; ?>>D3 Teknik
                                                    Telekomunikasi (Digital Connectivity)</option>
                                                <option value="D3 Teknik Informatika"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'D3 Teknik Informatika'): ?> selected <?php endif; ?>>D3 Teknik
                                                    Informatika</option>
                                                <option value="D3 Teknik Komputer"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'D3 Teknik Komputer'): ?> selected <?php endif; ?>>D3 Teknik Komputer
                                                </option>
                                                <option value="D3 Sistem Informasi"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'D3 Sistem Informasi'): ?> selected <?php endif; ?>>D3 Sistem
                                                    Informasi</option>
                                                <option value="D3 Digital Accounting (Sistem Informasi Akuntansi)"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'D3 Digital Accounting (Sistem Informasi Akuntansi)'): ?> selected <?php endif; ?>>D3 Digital
                                                    Accounting (Sistem Informasi Akuntansi)</option>
                                                <option value="D3 Hospitality & Culinary Art"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'D3 Hospitality & Culinary Art'): ?> selected <?php endif; ?>>D3 Hospitality &
                                                    Culinary Art</option>
                                                <option value="D3 Digital Marketing"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'D3 Digital Marketing'): ?> selected <?php endif; ?>>D3 Digital
                                                    Marketing</option>
                                                <option value="D3 Creative Multimedia"
                                                    <?php if(old('jurusan2', $pendaftaran->jurusan2) == 'D3 Creative Multimedia'): ?> selected <?php endif; ?>>D3 Creative
                                                    Multimedia</option>
                                            </select>
                                            <?php $__errorArgs = ['jurusan2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <footer class="footer pt-3  ">
            <?php echo $__env->make('dashboard.component.footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </footer>
    </div>
    <script>
        fetch('https://kanglerian.github.io/api-wilayah-indonesia/api/regencies/32.json')
            .then(response => response.json())
            .then(provinces => {
                var data = provinces;
                var tampung = '<option value="">Pilih Kota/Kabupaten</option>';
                data.forEach(element => {
                    tampung +=
                        `<option value="${element.name}">${element.name}</option>`
                });
                document.getElementById('kota').innerHTML = tampung;
            });
    </script>
    <script>
        var selectedValue = document.querySelector(`#kotaa`).getAttribute('data-selected');

        fetch(`https://kanglerian.github.io/api-wilayah-indonesia/api/regencies/32.json`)
            .then(response => response.json())
            .then(regencies => {
                var options = '<option value="">Pilih Kab/Kota</option>';
                regencies.forEach(element => {
                    options += `<option value="${element.name}">${element.name}</option>`;
                });

                // Mengisi select dengan options
                document.querySelector(`#kotaa`).innerHTML = options;

                // Set opsi yang dipilih berdasarkan data dari database
                document.querySelector(`#kotaa`).value = selectedValue;
            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.siswa.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eherd\OneDrive\Documents\Project\kta\resources\views/dashboard/pages/siswa/pendaftaran/index.blade.php ENDPATH**/ ?>