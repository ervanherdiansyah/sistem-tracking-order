
<?php $__env->startSection('title', 'Biodata'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <div class="row mt-4">
            <div class="col-lg-12 mb-lg-0 mb-4">
                <div class="card">
                    <div class="card-header pb-0">
                        <div class="d-flex align-items-center">
                            <p class="mb-0">Edit biodata</p>
                            <?php if($biodata != null): ?>
                                <button type="button" class="btn btn-primary btn-sm ms-auto" data-bs-toggle="modal"
                                    data-bs-target="#update">
                                    Edit biodata
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if($biodata == null): ?>
                            <form action="<?php echo e(url('/peserta/biodata/create')); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <input type="hidden" name="user_id" type="text" class="form-control"
                                        aria-label="Name" value="">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Nama
                                                Lengkap</label>
                                            <input name="nama_lengkap" type="text" class="form-control"
                                                placeholder="Nama Lengkap" aria-label="Name"
                                                value="<?php echo e(old('nama_lengkap')); ?>">
                                            <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Tempat
                                                Lahir</label>
                                            <input name="tempat_lahir" type="text" placeholder="Tempat lahir"
                                                class="form-control" value="<?php echo e(old('tempat_lahir')); ?>">
                                            <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Tanggal
                                                Lahir</label>
                                            <input name="tanggal_lahir" type="date" placeholder="Tanggal lahir"
                                                class="form-control" value="<?php echo e(old('tanggal_lahir')); ?>">
                                            <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Jenis
                                                Kelamin</label>
                                            <select name="jenis_kelamin" id="" class="form-control form-select">
                                                <option value="">Pilih</option>
                                                <option value="Laki-laki" <?php if(old('jenis_kelamin') == 'Laki-laki'): ?> selected <?php endif; ?>>
                                                    Laki-laki
                                                </option>
                                                <option value="Perempuan" <?php if(old('jenis_kelamin') == 'Perempuan'): ?> selected <?php endif; ?>>
                                                    Perempuan
                                                </option>
                                            </select>
                                            <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Agama</label>
                                            <select name="agama" id="" class="form-control form-select">
                                                <option value="">Pilih</option>
                                                <option value="Islam" <?php if(old('agama') == 'Islam'): ?> selected <?php endif; ?>>
                                                    Islam
                                                </option>
                                                <option value="Kristen Khatolik"
                                                    <?php if(old('agama') == 'Kristen Khatolik'): ?> selected <?php endif; ?>>
                                                    Kristen Khatolik
                                                </option>
                                                <option value="Kristen Protestan"
                                                    <?php if(old('agama') == 'Kristen Protestan'): ?> selected <?php endif; ?>>
                                                    Kristen Protestan
                                                </option>
                                                <option value="Budha" <?php if(old('agama') == 'Budha'): ?> selected <?php endif; ?>>
                                                    Budha
                                                </option>
                                                <option value="Hindu" <?php if(old('agama') == 'Hindu'): ?> selected <?php endif; ?>>
                                                    Hindu
                                                </option>
                                                <option value="konghuchu" <?php if(old('agama') == 'konghuchu'): ?> selected <?php endif; ?>>
                                                    konghuchu
                                                </option>
                                            </select>
                                            <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Email</label>
                                            <input name="email" placeholder="Email" class="form-control" type="email"
                                                value="<?php echo e(old('email')); ?>">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">No
                                                Hp</label>
                                            <input name="hp" placeholder="No Hp" class="form-control" type="text"
                                                value="<?php echo e(old('hp')); ?>">
                                            <?php $__errorArgs = ['hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Instagram</label>
                                            <input name="instagram" placeholder="Instagram" class="form-control"
                                                type="text" value="<?php echo e(old('instagram')); ?>">
                                            <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Alamat</label>
                                            <textarea name="alamat" id="" class="form-control"><?php echo e(old('alamat')); ?></textarea>
                                            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Asal
                                                sekolah</label>
                                            <input name="asal_sekolah" placeholder="Asal Sekolah" class="form-control"
                                                type="text" value="<?php echo e(old('asal_sekolah')); ?>">
                                            <?php $__errorArgs = ['asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Kota atau
                                                Kabupaten Sekolah</label>
                                            <select name="alamat_asal_sekolah" id="kota"
                                                class="form-control form-select">
                                                <option value="">Pilih Kab/Kota</option>
                                            </select>
                                            <?php $__errorArgs = ['alamat_asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Kelas</label>
                                            <select name="kelas" id="" class="form-control form-select">
                                                <option value="">Pilih</option>
                                                <option value="VII" <?php if(old('kelas') == 'VII'): ?> selected <?php endif; ?>>
                                                    VII
                                                </option>
                                                <option value="VIII" <?php if(old('kelas') == 'VIII'): ?> selected <?php endif; ?>>
                                                    VIII
                                                </option>
                                                <option value="IX" <?php if(old('kelas') == 'IX'): ?> selected <?php endif; ?>>
                                                    IX
                                                </option>
                                                <option value="X" <?php if(old('kelas') == 'X'): ?> selected <?php endif; ?>>
                                                    X
                                                </option>
                                                <option value="XI" <?php if(old('kelas') == 'XI'): ?> selected <?php endif; ?>>
                                                    XI
                                                </option>
                                                <option value="XII" <?php if(old('kelas') == 'XII'): ?> selected <?php endif; ?>>
                                                    XII
                                                </option>
                                                <option value="SLTP Sederajat"
                                                    <?php if(old('kelas') == 'SLTP Sederajat'): ?> selected <?php endif; ?>>
                                                    SLT Sederajat
                                                </option>
                                            </select>
                                            <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Jenjang
                                                Pendidikan</label>
                                            <select name="jurusan" id="" class="form-control form-select">
                                                <option value="">Pilih</option>
                                                <option value="SMA" <?php if(old('jurusan') == 'SMA'): ?> selected <?php endif; ?>>
                                                    SMA
                                                </option>
                                                <option value="SMK" <?php if(old('jurusan') == 'SMK'): ?> selected <?php endif; ?>>
                                                    SMK
                                                </option>
                                                <option value="MA" <?php if(old('jurusan') == 'MA'): ?> selected <?php endif; ?>>
                                                    MA
                                                </option>
                                                <option value="SMP" <?php if(old('jurusan') == 'SMP'): ?> selected <?php endif; ?>>
                                                    SMP
                                                </option>
                                                <option value="MTS" <?php if(old('jurusan') == 'MTS'): ?> selected <?php endif; ?>>
                                                    MTS
                                                </option>
                                            </select>
                                            <?php $__errorArgs = ['jurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn bg-gradient-dark w-100 my-4 mb-2">Submit</button>
                                </div>
                            </form>
                        <?php else: ?>
                            <form action="<?php echo e(url('/peserta/biodata/update/' . $biodata->id)); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Nama
                                                Lengkap</label>
                                            <input name="nama_lengkap" class="form-control" type="text"
                                                value="<?php echo e($biodata->nama_lengkap ?? ''); ?> "
                                                <?php if(isset($biodata) && $biodata->nama_lengkap): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Tempat
                                                Lahir</label>
                                            <input name="tempat_lahir" class="form-control" type="text"
                                                value="<?php echo e($biodata->tempat_lahir ?? ''); ?> "
                                                <?php if(isset($biodata) && $biodata->tempat_lahir): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Tanggal
                                                Lahir</label>
                                            <input name="tanggal_lahir" class="form-control" type="text"
                                                value="<?php echo e($biodata->tanggal_lahir ?? ''); ?> "
                                                <?php if(isset($biodata) && $biodata->tanggal_lahir): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Jenis
                                                Kelamin</label>
                                            <input name="jenis_kelamin" class="form-control" type="text"
                                                value="<?php echo e($biodata->jenis_kelamin ?? ''); ?>"
                                                <?php if(isset($biodata) && $biodata->jenis_kelamin): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Agama</label>
                                            <input name="agama" class="form-control" type="text"
                                                value="<?php echo e($biodata->agama ?? ''); ?>"
                                                <?php if(isset($biodata) && $biodata->agama): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Email</label>
                                            <input name="email" class="form-control" type="email"
                                                value="<?php echo e($biodata->email ?? ''); ?>"
                                                <?php if(isset($biodata) && $biodata->email): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Instagram</label>
                                            <input name="instagram" class="form-control" type="text"
                                                value="<?php echo e($biodata->instagram ?? ''); ?>"
                                                <?php if(isset($biodata) && $biodata->instagram): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Nomor
                                                Whatsapp</label>
                                            <input name="hp" class="form-control" type="text"
                                                value="<?php echo e($biodata->hp ?? ''); ?>"
                                                <?php if(isset($biodata) && $biodata->hp): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Jenjang
                                                Pendidikan</label>
                                            <input name="jurusan" class="form-control" type="text"
                                                value="<?php echo e($biodata->jurusan ?? ''); ?>"
                                                <?php if(isset($biodata) && $biodata->jurusan): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['jurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Kelas</label>
                                            <input name="kelas" class="form-control" type="text"
                                                value="<?php echo e($biodata->kelas ?? ''); ?>"
                                                <?php if(isset($biodata) && $biodata->kelas): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Asal
                                                Sekolah</label>
                                            <input name="asal_sekolah" class="form-control" type="text"
                                                value="<?php echo e($biodata->asal_sekolah ?? ''); ?>"
                                                <?php if(isset($biodata) && $biodata->asal_sekolah): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="example-text-input" class="form-control-label">Kota atau Kabupaten
                                                Sekolah</label>
                                            <input name="alamat_asal_sekolah" class="form-control" type="text"
                                                value="<?php echo e($biodata->alamat_asal_sekolah ?? ''); ?>"
                                                <?php if(isset($biodata) && $biodata->alamat_asal_sekolah): ?> readonly <?php endif; ?>>
                                            <?php $__errorArgs = ['alamat_asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <?php if(isset($biodata)): ?>
            <div class="modal fade" id="update" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Update biodata</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(url('/peserta/biodata/update/' . $biodata->id)); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Nama
                                                Lengkap</label>
                                            <input name="nama_lengkap" type="text" class="form-control"
                                                placeholder="Nama Lengkap" aria-label="Name"
                                                value="<?php echo e(old('nama_lengkap', $biodata->nama_lengkap)); ?>">
                                            <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Tempat
                                                Lahir</label>
                                            <input name="tempat_lahir" type="text" placeholder="Tempat lahir"
                                                class="form-control"
                                                value="<?php echo e(old('tempat_lahir', $biodata->tempat_lahir)); ?>">
                                            <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Tanggal
                                                Lahir</label>
                                            <input name="tanggal_lahir" type="date" placeholder="Tanggal lahir"
                                                class="form-control"
                                                value="<?php echo e(old('tanggal_lahir', $biodata->tanggal_lahir)); ?>">
                                            <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Jenis
                                                Kelamin</label>
                                            <select name="jenis_kelamin" id="" class="form-control form-select">
                                                <option value="">Pilih</option>
                                                <option value="Laki-laki"
                                                    <?php if(old('jenis_kelamin', $biodata->jenis_kelamin) == 'Laki-laki'): ?> selected <?php endif; ?>>Laki-laki</option>
                                                <option value="Perempuan"
                                                    <?php if(old('jenis_kelamin', $biodata->jenis_kelamin) == 'Perempuan'): ?> selected <?php endif; ?>>Perempuan</option>
                                            </select>
                                            <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Agama</label>
                                            <select name="agama" id="" class="form-control form-select">
                                                <option value="">Pilih</option>
                                                <option value="Islam" <?php if(old('agama', $biodata->agama) == 'Islam'): ?> selected <?php endif; ?>>
                                                    Islam</option>
                                                <option value="Kristen Khatolik"
                                                    <?php if(old('agama', $biodata->agama) == 'Kristen Khatolik'): ?> selected <?php endif; ?>>Kristen Khatolik
                                                </option>
                                                <option value="Kristen Protestan"
                                                    <?php if(old('agama', $biodata->agama) == 'Kristen Protestan'): ?> selected <?php endif; ?>>Kristen Protestan
                                                </option>
                                                <option value="Budha" <?php if(old('agama', $biodata->agama) == 'Budha'): ?> selected <?php endif; ?>>
                                                    Budha</option>
                                                <option value="Hindu" <?php if(old('agama', $biodata->agama) == 'Hindu'): ?> selected <?php endif; ?>>
                                                    Hindu</option>
                                                <option value="konghuchu"
                                                    <?php if(old('agama', $biodata->agama) == 'konghuchu'): ?> selected <?php endif; ?>>konghuchu</option>
                                            </select>
                                            <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Email</label>
                                            <input name="email" placeholder="Email" class="form-control"
                                                type="email" value="<?php echo e(old('email', $biodata->email)); ?>">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">No Hp</label>
                                            <input name="hp" placeholder="No Hp" class="form-control"
                                                type="text" value="<?php echo e(old('hp', $biodata->hp)); ?>">
                                            <?php $__errorArgs = ['hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Instagram</label>
                                            <input name="instagram" placeholder="Instagram" class="form-control"
                                                type="text" value="<?php echo e(old('instagram', $biodata->instagram)); ?>">
                                            <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Alamat</label>
                                            <textarea name="alamat" id="" class="form-control"><?php echo e(old('alamat', $biodata->alamat)); ?></textarea>
                                            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Asal
                                                sekolah</label>
                                            <input name="asal_sekolah" placeholder="Asal Sekolah" class="form-control"
                                                type="text" value="<?php echo e(old('asal_sekolah', $biodata->asal_sekolah)); ?>">
                                            <?php $__errorArgs = ['asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Kota atau Kabupaten
                                                Sekolah</label>
                                            <select name="alamat_asal_sekolah" id="kotaa"
                                                class="form-control form-select"
                                                data-selected="<?php echo e($biodata->alamat_asal_sekolah); ?>">
                                                <option value="">Pilih Kab/Kota</option>
                                            </select>
                                            <?php $__errorArgs = ['alamat_asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Kelas</label>
                                            <select name="kelas" id="" class="form-control form-select">
                                                <option value="">Pilih</option>
                                                <option value="VII" <?php if(old('kelas', $biodata->kelas) == 'VII'): ?> selected <?php endif; ?>>
                                                    VII</option>
                                                <option value="VIII" <?php if(old('kelas', $biodata->kelas) == 'VIII'): ?> selected <?php endif; ?>>
                                                    VIII</option>
                                                <option value="IX" <?php if(old('kelas', $biodata->kelas) == 'IX'): ?> selected <?php endif; ?>>
                                                    IX</option>
                                                <option value="X" <?php if(old('kelas', $biodata->kelas) == 'X'): ?> selected <?php endif; ?>>
                                                    X</option>
                                                <option value="XI" <?php if(old('kelas', $biodata->kelas) == 'XI'): ?> selected <?php endif; ?>>
                                                    XI</option>
                                                <option value="XII" <?php if(old('kelas', $biodata->kelas) == 'XII'): ?> selected <?php endif; ?>>
                                                    XII</option>
                                                <option value="SLTP Sederajat"
                                                    <?php if(old('kelas', $biodata->kelas) == 'SLTP Sederajat'): ?> selected <?php endif; ?>>SLTP Sederajat
                                                </option>
                                            </select>
                                            <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="example-text-input" class="form-control-label">Jenjang
                                                Pendidikan</label>
                                            <select name="jurusan" id="" class="form-control form-select">
                                                <option value="">Pilih</option>
                                                <option value="SMA" <?php if(old('jurusan', $biodata->jurusan) == 'SMA'): ?> selected <?php endif; ?>>
                                                    SMA</option>
                                                <option value="SMK" <?php if(old('jurusan', $biodata->jurusan) == 'SMK'): ?> selected <?php endif; ?>>
                                                    SMK</option>
                                                <option value="MA" <?php if(old('jurusan', $biodata->jurusan) == 'MA'): ?> selected <?php endif; ?>>
                                                    MA</option>
                                                <option value="SMP" <?php if(old('jurusan', $biodata->jurusan) == 'SMP'): ?> selected <?php endif; ?>>
                                                    SMP</option>
                                                <option value="MTS" <?php if(old('jurusan', $biodata->jurusan) == 'MTS'): ?> selected <?php endif; ?>>
                                                    MTS</option>
                                            </select>
                                            <?php $__errorArgs = ['jurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <footer class="footer pt-3  ">
            <?php echo $__env->make('dashboard.component.footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </footer>
    </div>
    <script>
        fetch('https://kanglerian.github.io/api-wilayah-indonesia/api/regencies/32.json')
            .then(response => response.json())
            .then(provinces => {
                var data = provinces;
                var tampung = '<option value="">Pilih Kota/Kabupaten</option>';
                data.forEach(element => {
                    tampung +=
                        `<option value="${element.name}">${element.name}</option>`
                });
                document.getElementById('kota').innerHTML = tampung;
            });
    </script>
    <script>
        var selectedValue = document.querySelector(`#kotaa`).getAttribute('data-selected');

        fetch(`https://kanglerian.github.io/api-wilayah-indonesia/api/regencies/32.json`)
            .then(response => response.json())
            .then(regencies => {
                var options = '<option value="">Pilih Kab/Kota</option>';
                regencies.forEach(element => {
                    options += `<option value="${element.name}">${element.name}</option>`;
                });

                // Mengisi select dengan options
                document.querySelector(`#kotaa`).innerHTML = options;

                // Set opsi yang dipilih berdasarkan data dari database
                document.querySelector(`#kotaa`).value = selectedValue;
            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.siswa.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eherd\OneDrive\Documents\Project\kta\resources\views/dashboard/pages/siswa/biodata/index.blade.php ENDPATH**/ ?>