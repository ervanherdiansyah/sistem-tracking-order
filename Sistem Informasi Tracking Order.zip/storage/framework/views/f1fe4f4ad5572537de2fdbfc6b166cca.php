<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('argon')); ?>/assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/img/logo.png')); ?>">
    <title>
        WEBSITE KTA
    </title>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
    <!-- Nucleo Icons -->
    <link href="<?php echo e(asset('argon')); ?>/assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="<?php echo e(asset('argon')); ?>/assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- Font Awesome Icons -->
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link href="<?php echo e(asset('argon')); ?>/assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- CSS Files -->
    <link id="pagestyle" href="<?php echo e(asset('argon')); ?>/assets/css/argon-dashboard.css?v=2.0.4" rel="stylesheet" />
</head>

<body class="">
    <main class="main-content  mt-0">
        <div class="page-header align-items-start min-vh-50 pt-5 pb-11 m-3 border-radius-lg"
            style="background-image: url('argon/assets/img/bgp.jpg'); background-position: top;">
            <span class="mask bg-gradient-dark opacity-6"></span>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-10 text-center mx-auto">
                        <h1 class="text-white mb-2 mt-5">WEBSITE OPREC ANGGOTA</h1>
                        <p class="text-lead text-white">Forum OSIS Jawa Barat adalah organisasi binaan Dinas Pendidikan
                            Provinsi Jawa Barat, Suatu wadah perkumpulan dan pengembangan kualitas diri para pelajar
                            tingkat SMA/SMK/MA Se-Derajat yang tergabung dalam kepengurusan OSIS ditiap sekolah dengan
                            Visi “menjadi inkubator pemimpin muda Jawa Barat berkarakter STRONG untuk Indonesia Emas
                            Tahun 2045” FOJB ini Didirikan oleh 6 anak muda hebat asli Jawa Barat sejak 5 Januari 2013
                            menjadikan FOJB sebagai Perkumpulan OSIS tertua di Indonesia. Proses pengukuhannya secara
                            resmi dilakukan oleh Gubernur Jawa Barat saat itu. Dewasa kini Ikatan Alumni FOJB atau kerap
                            disebut IKAL telah mencapai 15.000 anggota yang tersebar di berbagai posisi strategis di
                            Jawa Barat bahkan Luar Negeri. Kedepannya Forum OSIS Jawa Barat akan terus berbenah hingga
                            alumni-alumni nya dapat terus berkarya dan bermanfaat untuk masyarakat Indonesia..</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row mt-lg-n10 mt-md-n11 mt-n10 justify-content-center">
                <div id="register-form-container">
                    <div class="col-xl-6 col-lg-5 col-md-7 mx-auto">
                        <div class="card z-index-0">
                            <div class="card-header text-center pt-4">
                                <h5>Register Akun </h5>
                            </div>
                            <div class="card-body">
                                <form id="register-form" role="form" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col">
                                            <div class="mb-3">
                                                <input name="name" type="text" class="form-control"
                                                    placeholder="Name" aria-label="Name" value="<?php echo e(old('name')); ?>">
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="mb-3">
                                                <input name="email" type="email" class="form-control"
                                                    placeholder="Email" aria-label="Email" value="<?php echo e(old('email')); ?>">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="mb-3">
                                                <input name="password" type="password" class="form-control"
                                                    placeholder="Password" aria-label="Password">
                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="mb-3">
                                                <input name="password_confirmation" type="password" class="form-control"
                                                    placeholder="Password Confirmation" aria-label="Password">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-check form-check-info text-start">
                                        <input class="form-check-input" type="checkbox" value=""
                                            id="flexCheckDefault" checked>
                                        <label class="form-check-label" for="flexCheckDefault">
                                            I agree the <a href="javascript:;"
                                                class="text-dark font-weight-bolder">Terms
                                                and Conditions</a>
                                        </label>
                                    </div>
                                    <div class="text-center">
                                        <button type="submit" class="btn bg-gradient-dark w-100 my-4 mb-2">Sign
                                            up</button>
                                    </div>
                                    <p class="text-sm mt-3 mb-0">Already have an account? <a href="<?php echo e(url('/')); ?>"
                                            class="text-dark font-weight-bolder">Sign
                                            in</a></p>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="registration-form-container" style="display: none;">
                    <div class="col-xl-8 col-lg-5 col-md-7 mx-auto">
                        <div class="card z-index-0">
                            <div class="card-header text-center pt-4">
                                <h5>Form Pendaftaran </h5>
                            </div>
                            <div class="card-body">
                                <form role="form" action="<?php echo e(url('/createform')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <input type="hidden" name="user_id" type="text" class="form-control"
                                            aria-label="Name" value="">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="example-text-input" class="form-control-label">Nama
                                                    Lengkap</label>
                                                <input name="nama_lengkap" type="text" class="form-control"
                                                    placeholder="Nama Lengkap" aria-label="Name"
                                                    value="<?php echo e(old('nama_lengkap')); ?>">
                                                <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="example-text-input" class="form-control-label">Tempat
                                                    Lahir</label>
                                                <input name="tempat_lahir" type="text" placeholder="Tempat lahir"
                                                    class="form-control" value="<?php echo e(old('tempat_lahir')); ?>">
                                                <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="example-text-input" class="form-control-label">Tanggal
                                                    Lahir</label>
                                                <input name="tanggal_lahir" type="date"
                                                    placeholder="Tanggal lahir" class="form-control"
                                                    value="<?php echo e(old('tanggal_lahir')); ?>">
                                                <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="example-text-input" class="form-control-label">Jenis
                                                    Kelamin</label>
                                                <select name="jenis_kelamin" id=""
                                                    class="form-control form-select">
                                                    <option value="">Pilih</option>
                                                    <option value="Laki-laki"
                                                        <?php if(old('jenis_kelamin') == 'Laki-laki'): ?> selected <?php endif; ?>>
                                                        Laki-laki
                                                    </option>
                                                    <option value="Perempuan"
                                                        <?php if(old('jenis_kelamin') == 'Perempuan'): ?> selected <?php endif; ?>>
                                                        Perempuan
                                                    </option>
                                                </select>
                                                <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="example-text-input"
                                                    class="form-control-label">Agama</label>
                                                <select name="agama" id=""
                                                    class="form-control form-select">
                                                    <option value="">Pilih</option>
                                                    <option value="Islam"
                                                        <?php if(old('agama') == 'Islam'): ?> selected <?php endif; ?>>Islam
                                                    </option>
                                                    <option value="Kristen Khatolik"
                                                        <?php if(old('agama') == 'Kristen Khatolik'): ?> selected <?php endif; ?>>
                                                        Kristen Khatolik
                                                    </option>
                                                    <option value="Kristen Protestan"
                                                        <?php if(old('agama') == 'Kristen Protestan'): ?> selected <?php endif; ?>>
                                                        Kristen Protestan
                                                    </option>
                                                    <option value="Budha"
                                                        <?php if(old('agama') == 'Budha'): ?> selected <?php endif; ?>>Budha
                                                    </option>
                                                    <option value="Hindu"
                                                        <?php if(old('agama') == 'Hindu'): ?> selected <?php endif; ?>>Hindu
                                                    </option>
                                                    <option value="konghuchu"
                                                        <?php if(old('agama') == 'konghuchu'): ?> selected <?php endif; ?>>konghuchu
                                                    </option>
                                                </select>
                                                <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="example-text-input"
                                                    class="form-control-label">Email</label>
                                                <input name="email" placeholder="Email" class="form-control"
                                                    type="email" value="<?php echo e(old('email')); ?>">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="example-text-input" class="form-control-label">No
                                                    Hp</label>
                                                <input name="hp" placeholder="No Hp" class="form-control"
                                                    type="text" value="<?php echo e(old('hp')); ?>">
                                                <?php $__errorArgs = ['hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="example-text-input"
                                                    class="form-control-label">Instagram</label>
                                                <input name="instagram" placeholder="Instagram" class="form-control"
                                                    type="text" value="<?php echo e(old('instagram')); ?>">
                                                <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="example-text-input"
                                                    class="form-control-label">Alamat</label>
                                                <textarea name="alamat" id="" class="form-control"><?php echo e(old('alamat')); ?></textarea>
                                                <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="example-text-input" class="form-control-label">Asal
                                                    sekolah</label>
                                                <input name="asal_sekolah" placeholder="Asal Sekolah"
                                                    class="form-control" type="text"
                                                    value="<?php echo e(old('asal_sekolah')); ?>">
                                                <?php $__errorArgs = ['asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="example-text-input" class="form-control-label">Kota atau
                                                    Kabupaten Sekolah</label>
                                                <select name="alamat_asal_sekolah" id="kota"
                                                    class="form-control form-select">
                                                    <option value="">Pilih Kab/Kota</option>
                                                </select>
                                                <?php $__errorArgs = ['alamat_asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="example-text-input"
                                                    class="form-control-label">Kelas</label>
                                                <select name="kelas" id=""
                                                    class="form-control form-select">
                                                    <option value="">Pilih</option>
                                                    <option value="VII"
                                                        <?php if(old('kelas') == 'VII'): ?> selected <?php endif; ?>>
                                                        VII
                                                    </option>
                                                    <option value="VIII"
                                                        <?php if(old('kelas') == 'VIII'): ?> selected <?php endif; ?>>
                                                        VIII
                                                    </option>
                                                    <option value="IX"
                                                        <?php if(old('kelas') == 'IX'): ?> selected <?php endif; ?>>
                                                        IX
                                                    </option>
                                                    <option value="X"
                                                        <?php if(old('kelas') == 'X'): ?> selected <?php endif; ?>>
                                                        X
                                                    </option>
                                                    <option value="XI"
                                                        <?php if(old('kelas') == 'XI'): ?> selected <?php endif; ?>>
                                                        XI
                                                    </option>
                                                    <option value="XII"
                                                        <?php if(old('kelas') == 'XII'): ?> selected <?php endif; ?>>
                                                        XII
                                                    </option>
                                                    <option value="SLTP Sederajat"
                                                        <?php if(old('kelas') == 'SLTP Sederajat'): ?> selected <?php endif; ?>>
                                                        SLT Sederajat
                                                    </option>
                                                </select>
                                                <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="example-text-input" class="form-control-label">Jenjang
                                                    Pendidikan</label>
                                                <select name="jurusan" id=""
                                                    class="form-control form-select">
                                                    <option value="">Pilih</option>
                                                    <option value="SMA"
                                                        <?php if(old('jurusan') == 'SMA'): ?> selected <?php endif; ?>>
                                                        SMA
                                                    </option>
                                                    <option value="SMK"
                                                        <?php if(old('jurusan') == 'SMK'): ?> selected <?php endif; ?>>
                                                        SMK
                                                    </option>
                                                    <option value="MA"
                                                        <?php if(old('jurusan') == 'MA'): ?> selected <?php endif; ?>>
                                                        MA
                                                    </option>
                                                    <option value="SMP"
                                                        <?php if(old('jurusan') == 'SMP'): ?> selected <?php endif; ?>>
                                                        SMP
                                                    </option>
                                                    <option value="MTS"
                                                        <?php if(old('jurusan') == 'MTS'): ?> selected <?php endif; ?>>
                                                        MTS
                                                    </option>
                                                </select>
                                                <?php $__errorArgs = ['jurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-center">
                                        <button type="submit"
                                            class="btn bg-gradient-dark w-100 my-4 mb-2">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('argon')); ?>/assets/js/core/popper.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/assets/js/core/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/assets/js/plugins/smooth-scrollbar.min.js"></script>
    <script>
        var win = navigator.platform.indexOf('Win') > -1;
        if (win && document.querySelector('#sidenav-scrollbar')) {
            var options = {
                damping: '0.5'
            }
            Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
        }
    </script>
    <!-- Github buttons -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="<?php echo e(asset('argon')); ?>/assets/js/argon-dashboard.min.js?v=2.0.4"></script>
    <script>
        // function getProvinces() {
        //     fetch('https://kanglerian.github.io/api-wilayah-indonesia/api/regencies/32.json')
        //         .then(response => response.json())
        //         .then(provinces => {
        //             const provinceSelect = document.getElementById('kota');
        //             provinceSelect.innerHTML = '<option value="">Pilih Provinsi</option>';
        //             provinces.forEach(province => {
        //                 const option = document.createElement('option');
        //                 option.text = province.name;
        //                 option.value = province.name; // Nilai dari opsi disetel menjadi nama provinsi
        //                 option.dataset.id = province.id; // Menyimpan ID provinsi ke dalam atribut data
        //                 provinceSelect.add(option);
        //             });
        //         });
        // }
        fetch('https://kanglerian.github.io/api-wilayah-indonesia/api/regencies/32.json')
            .then(response => response.json())
            .then(provinces => {
                var data = provinces;
                var tampung = '<option value="">Pilih Kota/Kabupaten</option>';
                data.forEach(element => {
                    tampung +=
                        `<option value="${element.name}">${element.name}</option>`
                });
                document.getElementById('kota').innerHTML = tampung;
            });
    </script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        // Penanganan acara untuk tombol "Sign up"
        $(document).on('submit', '#register-form', function(event) {
            // Lakukan AJAX request untuk membuat akun
            $.ajax({
                url: '/createregister',
                method: 'POST',
                data: $(this).serialize(), // Serialize formulir untuk dikirimkan
                success: function(response) {

                    sessionStorage.setItem('registerData', JSON.stringify(response));
                    // Sembunyikan formulir register akun setelah berhasil membuat akun
                    $('#register-form-container').hide();
                    // Tampilkan formulir pendaftaran setelah berhasil mendaftar akun
                    $('#registration-form-container').show();
                    // Tampilkan pesan sukses atau lakukan tindakan lain yang sesuai
                    Swal.fire({
                        icon: 'success',
                        title: 'Registration Successful!',
                        text: 'You have successfully registered your account.',
                        showConfirmButton: false,
                        timer: 2000 // Menampilkan pesan selama 2 detik
                    });
                    // Mengambil ID pengguna dari respons server
                    console.log(response);
                    var userId = response.id;
                    // Menetapkan nilai ID pengguna ke input tersembunyi
                    $('input[name="user_id"]').val(userId);
                    // $('#register-form-container').show();
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error);
                    // Menampilkan pesan kesalahan kepada pengguna
                    var errors = xhr.responseJSON
                        .errors; // Mendapatkan semua pesan kesalahan dari respons JSON

                    // Menampilkan pesan kesalahan untuk setiap field inputan
                    if (errors) {
                        if (errors.email) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Email Error',
                                text: errors.email[
                                    0], // Menampilkan pesan kesalahan untuk email
                                showConfirmButton: false,
                                timer: 2000 // Menampilkan pesan selama 2 detik
                            });
                        }
                        if (errors.password) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Password Error',
                                text: errors.password[
                                    0], // Menampilkan pesan kesalahan untuk password
                                showConfirmButton: false,
                                timer: 2000 // Menampilkan pesan selama 2 detik
                            });
                        }
                        // Tambahan penanganan pesan kesalahan untuk field inputan lainnya
                    }
                }

            });

            // Jangan lakukan submit form secara default
            event.preventDefault();
        });

        // Saat dokumen dimuat
        $(document).ready(function() {
            // Periksa apakah ada data register akun dalam sesi
            var registerData = JSON.parse(sessionStorage.getItem('registerData'));
            if (registerData) {
                // Sembunyikan formulir register akun dan tampilkan formulir pendaftaran
                $('#register-form-container').hide();
                $('#registration-form-container').show();

                // Tampilkan data register akun di form pendaftaran (jika perlu)
                // contoh: $('#nama').val(registerData.nama);
                // sessionStorage.removeItem('registerData');

            }
            // Jika masih ada sesi 'registerData' tetapi validasi gagal, jangan hapus sesi
            else if (registerData === null) {
                // Hapus data register akun dari sesi (opsional)
            }
        });
    </script>
</body>

</html>
<?php /**PATH C:\Users\eherd\OneDrive\Documents\Project\kta\resources\views/auths/form.blade.php ENDPATH**/ ?>