
<?php $__env->startSection('title', 'Pembayaran'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <div class="row mt-4">
            <div class="col-lg-12 mb-lg-0 mb-4">
                <div class="card d-flex justify-content-center " style="height: ;">
                    <div class="card-header pb-0 pt-3 bg-info">
                        <h6 class="text-capitalize">Pembayaran</h6>
                    </div>
                    <div class="container"
                        style="height: ; display: flex; justify-content: center; align-items: center;  margin-top:3px; margin-bottom:3px">
                        <div class="card" style="width: 400px;">
                            <div class="card-header pb-0 pt-3 bg-transparent">
                                
                            </div>
                            <?php if($pembayaran->status === 'Unpaid'): ?>
                                <div class="card-body p-3">
                                    <div style="text-align: center; ">
                                        <i class="fa fa-money" style="font-size: 100px; color: #007bff;"></i>
                                    </div>
                                    <div style="text-align: center;">
                                        <p type="button"
                                            style="font-size: 15px; color: #007bff; border: none; background: none;">Lakukan
                                            pembayaran disini !!!</p>
                                        <button type="button" class="btn btn-info" id="pay-button"
                                            style="font-size: 20px; color: #007bff; border: none; background: none;">Bayar
                                            Sekarang
                                        </button>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="card-body p-3">
                                    <div style="text-align: center; ">
                                        <i class="fa fa-check-circle-o" style="font-size: 100px; color: #42ec8f;"></i>
                                    </div>
                                    <div style="text-align: center;">
                                        <p type="button"
                                            style="font-size: 15px; color: #007bff; border: none; background: none;">Anda
                                            Sudah Membayar !!!</p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="footer pt-3  ">
            <?php echo $__env->make('dashboard.component.footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </footer>
    </div>
<?php $__env->stopSection(); ?>
<?php if($pembayaran->status === 'Unpaid'): ?>
    <?php $__env->startPush('midtrans'); ?>
        <script type="text/javascript">
            // For example trigger on button clicked, or any time you need
            var payButton = document.getElementById('pay-button');
            payButton.addEventListener('click', function() {
                // Trigger snap popup. @TODO: Replace TRANSACTION_TOKEN_HERE with your transaction token
                window.snap.pay('<?php echo e($snapToken); ?>', {
                    onSuccess: function(result) {
                        /* You may add your own implementation here */
                        window.location.href = '/peserta/home';
                    },
                    onPending: function(result) {
                        /* You may add your own implementation here */
                        alert("wating your payment!");
                        console.log(result);
                    },
                    onError: function(result) {
                        /* You may add your own implementation here */
                        alert("payment failed!");
                        console.log(result);
                    },
                    onClose: function() {
                        /* You may add your own implementation here */
                        alert('you closed the popup without finishing the payment');
                    }
                })
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>

<?php echo $__env->make('dashboard.layouts.siswa.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eherd\OneDrive\Documents\Project\kta\resources\views/dashboard/pages/siswa/pembayaran/index.blade.php ENDPATH**/ ?>