
<?php $__env->startSection('title', 'Data Peserta'); ?>
<?php $__env->startSection('css'); ?>
    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.css" />

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4 ">
        <div class="row">
            <div class="col-12 ">
                <div class="card mb-4 ">
                    <div class="card-header pb-0">
                        <h6 class="d-lg-none">Data Peserta</h6>
                        <div class="d-flex align-items-center">
                            <h6 class="d-none d-lg-block">Data Peserta</h6>

                            <div class="d-flex flex-wrap align-items-center ms-auto gap-2">
                                <button type="button" class="btn btn-primary btn-sm ms-auto" data-bs-toggle="modal"
                                    data-bs-target="#filterkota">
                                    Filter Kota
                                </button>
                                <a href="<?php echo e(url('/dashboard/cetak-all-kta-peserta')); ?>" target="_blank"
                                    class="btn btn-primary btn-sm">Cetak
                                    KTA</a>
                                
                                

                                

                            </div>
                        </div>
                    </div>
                    <div class="card-body px-4 pt-0 pb-2">
                        <div class="table-responsive p-0">
                            <table id="myTable" class="table align-items-center mb-0 display">
                                <thead>
                                    <tr>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            Nama</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            Kelas</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            Jurusan</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            Asal Sekolah</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            Asal Kota/Kabupaten Sekolah</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            Tempat Lahir</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            Tanggal Lahir</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            Jenis Kelamin</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            Agama</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            email</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            No Hp</th>

                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            Instragram</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            Alamat</th>
                                        <th class="text-secondary opacity-7"></th>
                                    </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="footer pt-3  ">
            <?php echo $__env->make('dashboard.component.footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </footer>
    </div>

    <!-- Modal Create Data-->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Pendaftaran</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(url('/dashboard/pendaftaran/create')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <input type="hidden" name="user_id" type="text" class="form-control" aria-label="Name"
                                value="">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="example-text-input" class="form-control-label">Nama
                                        Lengkap</label>
                                    <input name="nama_lengkap" type="text" class="form-control"
                                        placeholder="Nama Lengkap" aria-label="Name" value="<?php echo e(old('nama_lengkap')); ?>">
                                    <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="example-text-input" class="form-control-label">Tempat
                                        Lahir</label>
                                    <input name="tempat_lahir" type="text" placeholder="Tempat lahir"
                                        class="form-control" value="<?php echo e(old('tempat_lahir')); ?>">
                                    <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="example-text-input" class="form-control-label">Tanggal
                                        Lahir</label>
                                    <input name="tanggal_lahir" type="date" placeholder="Tanggal lahir"
                                        class="form-control" value="<?php echo e(old('tanggal_lahir')); ?>">
                                    <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="example-text-input" class="form-control-label">Jenis
                                        Kelamin</label>
                                    <select name="jenis_kelamin" id="" class="form-control form-select">
                                        <option value="">Pilih</option>
                                        <option value="Laki-laki" <?php if(old('jenis_kelamin') == 'Laki-laki'): ?> selected <?php endif; ?>>
                                            Laki-laki
                                        </option>
                                        <option value="Perempuan" <?php if(old('jenis_kelamin') == 'Perempuan'): ?> selected <?php endif; ?>>
                                            Perempuan
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="example-text-input" class="form-control-label">Agama</label>
                                    <select name="agama" id="" class="form-control form-select">
                                        <option value="">Pilih</option>
                                        <option value="Islam" <?php if(old('agama') == 'Islam'): ?> selected <?php endif; ?>>Islam
                                        </option>
                                        <option value="Kristen Khatolik" <?php if(old('agama') == 'Kristen Khatolik'): ?> selected <?php endif; ?>>
                                            Kristen Khatolik
                                        </option>
                                        <option value="Kristen Protestan"
                                            <?php if(old('agama') == 'Kristen Protestan'): ?> selected <?php endif; ?>>
                                            Kristen Protestan
                                        </option>
                                        <option value="Budha" <?php if(old('agama') == 'Budha'): ?> selected <?php endif; ?>>Budha
                                        </option>
                                        <option value="Hindu" <?php if(old('agama') == 'Hindu'): ?> selected <?php endif; ?>>Hindu
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="example-text-input" class="form-control-label">Email</label>
                                    <input name="email" placeholder="Email" class="form-control" type="email"
                                        value="<?php echo e(old('email')); ?>">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="example-text-input" class="form-control-label">No
                                        Hp</label>
                                    <input name="hp" placeholder="No Hp" class="form-control" type="text"
                                        value="<?php echo e(old('hp')); ?>">
                                    <?php $__errorArgs = ['hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="example-text-input" class="form-control-label">Instagram</label>
                                    <input name="instagram" placeholder="Instagram" class="form-control" type="text"
                                        value="<?php echo e(old('instagram')); ?>">
                                    <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="example-text-input" class="form-control-label">Alamat</label>
                                    <textarea name="alamat" id="" class="form-control"><?php echo e(old('alamat')); ?></textarea>
                                    <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="example-text-input" class="form-control-label">Asal
                                        sekolah</label>
                                    <input name="asal_sekolah" placeholder="Asal Sekolah" class="form-control"
                                        type="text" value="<?php echo e(old('asal_sekolah')); ?>">
                                    <?php $__errorArgs = ['asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="example-text-input" class="form-control-label">Kota atau
                                        Kabupaten Sekolah</label>
                                    <select name="alamat_asal_sekolah" id="kota" class="form-control form-select">
                                        <option value="">Pilih Kab/Kota</option>
                                    </select>
                                    <?php $__errorArgs = ['alamat_asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="example-text-input" class="form-control-label">Kelas</label>
                                    <select name="kelas" id="" class="form-control form-select">
                                        <option value="">Pilih</option>
                                        <option value="VII" <?php if(old('kelas') == 'VII'): ?> selected <?php endif; ?>>
                                            VII
                                        </option>
                                        <option value="VIII" <?php if(old('kelas') == 'VIII'): ?> selected <?php endif; ?>>
                                            VIII
                                        </option>
                                        <option value="IX" <?php if(old('kelas') == 'IX'): ?> selected <?php endif; ?>>
                                            IX
                                        </option>
                                        <option value="X" <?php if(old('kelas') == 'X'): ?> selected <?php endif; ?>>
                                            X
                                        </option>
                                        <option value="XI" <?php if(old('kelas') == 'XI'): ?> selected <?php endif; ?>>
                                            XI
                                        </option>
                                        <option value="XII" <?php if(old('kelas') == 'XII'): ?> selected <?php endif; ?>>
                                            XII
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="example-text-input" class="form-control-label">Jurusan</label>
                                    <select name="jurusan" id="" class="form-control form-select">
                                        <option value="">Pilih</option>
                                        <option value="SMA" <?php if(old('jurusan') == 'SMA'): ?> selected <?php endif; ?>>
                                            SMA
                                        </option>
                                        <option value="SMK" <?php if(old('jurusan') == 'SMK'): ?> selected <?php endif; ?>>
                                            SMK
                                        </option>
                                        <option value="MA" <?php if(old('jurusan') == 'MA'): ?> selected <?php endif; ?>>
                                            MA
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['jurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End Modal Create Data-->

    <!-- Modal Filter Data-->
    <div class="modal fade" id="filterkota" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Pendaftaran</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="filterForm" action="<?php echo e(url('/dashboard/pendaftaran')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="example-text-input" class="form-control-label">Kota / Kabupaten</label>
                                    <select name="filter_kota" id="filter_kota" class="form-control form-select">
                                        <option value="">Pilih</option>
                                        <?php $__currentLoopData = $kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item['name']); ?>"><?php echo e($item['name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['filter_kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Filter</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- End Modal Filter Data-->

    <!-- Modal Delete Data-->
    
    <!-- End Modal Delete Data-->

    <!-- Modal Update Data-->
    
    <!-- End Modal Update Data-->

    <!-- Modal Verifikasi Data-->
    
    <!-- End Modal Verifikasi Data-->

    <!-- Modal Import Data-->
    <div class="modal fade" id="import" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Import Data Pendaftaran</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(url('/dashboard/peserta/import')); ?>" method="Post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="example-text-input" class="form-control-label">Import Data Pendaftaran</label>
                                <input name="upload" class="form-control" type="file">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End Modal Import Data-->
    <div id="modals-container"></div>

    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <!-- Tautkan file JavaScript jQuery -->

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            loadData();

            function loadData() {
                var table = $('#myTable').DataTable({
                    processing: true,
                    pagination: true,
                    responsive: true,
                    serverSide: true,
                    searching: true,
                    ordering: false,
                    ajax: {
                        url: "<?php echo e(url('/dashboard/peserta')); ?>",
                        data: function(d) {
                            d.filter_kota = $('#filter_kota').val();
                        }
                    },
                    columns: [{
                            data: "nama_lengkap",
                            name: "nama_lengkap"
                        },
                        {
                            data: "kelas",
                            name: "kelas"
                        },
                        {
                            data: "jurusan",
                            name: "jurusan"
                        },
                        {
                            data: "asal_sekolah",
                            name: "asal_sekolah"
                        },
                        {
                            data: "alamat_asal_sekolah",
                            name: "alamat_asal_sekolah"
                        },
                        {
                            data: "tempat_lahir",
                            name: "tempat_lahir"
                        },
                        {
                            data: "tanggal_lahir",
                            name: "tanggal_lahir"
                        },
                        {
                            data: "jenis_kelamin",
                            name: "jenis_kelamin"
                        },
                        {
                            data: "agama",
                            name: "agama"
                        },
                        {
                            data: "email",
                            name: "email"
                        },
                        {
                            data: "hp",
                            name: "hp"
                        },
                        {
                            data: "instagram",
                            name: "instagram"
                        },
                        {
                            data: "alamat",
                            name: "alamat"
                        },
                        {
                            data: "action",
                            name: "action"
                        },
                    ],
                    drawCallback: function(settings) {
                        var api = this.api();
                        $('#modals-container').empty();
                        api.rows().every(function(rowIdx, tableLoop, rowLoop) {
                            var data = this.data();
                            var modalId = data.id;
                            var userName = $('<div>').html(data.user_id).text()
                                .trim(); // Decode HTML entities and trim spaces
                            $('#modals-container').append(`
                            <!-- Delete Modal -->
                            <div class="modal fade" id="delete${data.id}" tabindex="-1" aria-labelledby="deleteLabel${data.id}" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="deleteLabel${data.id}">Delete User ${userName}</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(url('/dashboard/peserta/destroy/')); ?>/${data.id}" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <p>Apakah anda yakin ingin menghapus data ini?</p>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-primary">Delete</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Update Modal -->
                            <div class="modal fade" id="update${data.id}" tabindex="-1" aria-labelledby="updateLabel${data.id}" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="updateLabel${data.id}">Update peserta</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(url('/dashboard/peserta/update/')); ?>/${data.id}" method="POST" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="row">
                                                    <input type="hidden" name="user_id" value="${data.user_id}">
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="nama_lengkap${data.id}" class="form-control-label">Nama Lengkap</label>
                                                            <input name="nama_lengkap" type="text" class="form-control" id="nama_lengkap${data.id}" placeholder="Nama Lengkap" value="${data.nama_lengkap}">
                                                            <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="tempat_lahir${data.id}" class="form-control-label">Tempat Lahir</label>
                                                            <input name="tempat_lahir" type="text" class="form-control" id="tempat_lahir${data.id}" placeholder="Tempat lahir" value="${data.tempat_lahir}">
                                                            <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="tanggal_lahir${data.id}" class="form-control-label">Tanggal Lahir</label>
                                                            <input name="tanggal_lahir" type="date" class="form-control" id="tanggal_lahir${data.id}" value="${data.tanggal_lahir}">
                                                            <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="jenis_kelamin${data.id}" class="form-control-label">Jenis Kelamin</label>
                                                            <select class="form-control form-select" name="jenis_kelamin" id="jenis_kelamin${data.id}">
                                                                <option selected>Pilih...</option>
                                                                <option value="Laki-laki" ${data.jenis_kelamin === 'Laki-laki' ? 'selected' : ''}>Laki-Laki</option>
                                                                <option value="Perempuan" ${data.jenis_kelamin === 'Perempuan' ? 'selected' : ''}>Perempuan</option>
                                                            </select>
                                                            <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="agama${data.id}" class="form-control-label">Agama</label>
                                                            <select name="agama" id="agama${data.id}" class="form-control form-select">
                                                                <option value="">Pilih</option>
                                                                <option value="Islam" ${data.agama === 'Islam' ? 'selected' : ''}>Islam</option>
                                                                <option value="Kristen Khatolik" ${data.agama === 'Kristen Khatolik' ? 'selected' : ''}>Kristen Khatolik</option>
                                                                <option value="Kristen Protestan" ${data.agama === 'Kristen Protestan' ? 'selected' : ''}>Kristen Protestan</option>
                                                                <option value="Budha" ${data.agama === 'Budha' ? 'selected' : ''}>Budha</option>
                                                                <option value="Hindu" ${data.agama === 'Hindu' ? 'selected' : ''}>Hindu</option>
                                                            </select>
                                                            <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="email${data.id}" class="form-control-label">Email</label>
                                                            <input name="email" type="email" class="form-control" id="email${data.id}" placeholder="Email" value="${data.email}">
                                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="hp${data.id}" class="form-control-label">No Hp</label>
                                                            <input name="hp" type="text" class="form-control" id="hp${data.id}" placeholder="No Hp" value="${data.hp}">
                                                            <?php $__errorArgs = ['hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="instagram${data.id}" class="form-control-label">Instagram</label>
                                                            <input name="instagram" type="text" class="form-control" id="instagram${data.id}" placeholder="Instagram" value="${data.instagram}">
                                                            <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="alamat${data.id}" class="form-control-label">Alamat</label>
                                                            <textarea name="alamat" class="form-control" id="alamat${data.id}">${data.alamat}</textarea>
                                                            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="example-text-input" class="form-control-label">Asal
                                                                sekolah</label>
                                                            <input name="asal_sekolah" placeholder="Asal Sekolah"
                                                                class="form-control" type="text"
                                                                value="${data.asal_sekolah}">
                                                            <?php $__errorArgs = ['asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="alamat_asal_sekolah${modalId}" class="form-control-label">Kota atau Kabupaten Sekolah</label>
                                                            <select name="alamat_asal_sekolah" id="alamat_asal_sekolah${modalId}" class="form-control form-select">
                                                                <option value="">Pilih Kab/Kota</option>
                                                            </select>
                                                            <?php $__errorArgs = ['alamat_asal_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="kelas${data.id}" class="form-control-label">Kelas</label>
                                                            <select name="kelas" id="kelas${data.id}" class="form-control form-select">
                                                                <option value="">Pilih</option>
                                                                <option value="VII" ${data.kelas === 'VII' ? 'selected' : ''}>VII</option>
                                                                <option value="VIII" ${data.kelas === 'VIII' ? 'selected' : ''}>VIII</option>
                                                                <option value="IX" ${data.kelas === 'IX' ? 'selected' : ''}>IX</option>
                                                                <option value="X" ${data.kelas === 'X' ? 'selected' : ''}>X</option>
                                                                <option value="XI" ${data.kelas === 'XI' ? 'selected' : ''}>XI</option>
                                                                <option value="XII" ${data.kelas === 'XII' ? 'selected' : ''}>XII</option>
                                                            </select>
                                                            <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <label for="jurusan${data.id}" class="form-control-label">Jurusan</label>
                                                            <select name="jurusan" id="jurusan${data.id}" class="form-control form-select">
                                                                <option value="">Pilih</option>
                                                                <option value="SMA" ${data.jurusan === 'SMA' ? 'selected' : ''}>SMA</option>
                                                                <option value="SMK" ${data.jurusan === 'SMK' ? 'selected' : ''}>SMK</option>
                                                                <option value="MA" ${data.jurusan === 'MA' ? 'selected' : ''}>MA</option>
                                                            </select>
                                                            <?php $__errorArgs = ['jurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    <button type="submit" class="btn btn-primary">Update</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `);
                            // Ambil data kota dari API dan tampilkan di opsi pilihan
                            fetch(
                                    `https://kanglerian.github.io/api-wilayah-indonesia/api/regencies/32.json`
                                )
                                .then(response => response.json())
                                .then(regencies => {
                                    var options = '';
                                    regencies.forEach(element => {
                                        options +=
                                            `<option value="${element.name}">${element.name}</option>`;
                                    });
                                    $(`#alamat_asal_sekolah${modalId}`).html(options);

                                    // Set opsi yang dipilih berdasarkan data dari database
                                    $(`#alamat_asal_sekolah${modalId}`).val(data
                                        .alamat_asal_sekolah);
                                });
                        });
                    }

                });
                $('#filterForm').on('submit', function(e) {
                    e.preventDefault();
                    table.ajax.reload();
                });
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eherd\OneDrive\Documents\Project\kta\resources\views/dashboard/pages/pendaftaran/peserta.blade.php ENDPATH**/ ?>