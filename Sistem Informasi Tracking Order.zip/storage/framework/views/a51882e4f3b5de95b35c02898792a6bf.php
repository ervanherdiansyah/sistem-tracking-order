<!--
=========================================================
* Argon Dashboard 2 - v2.0.4
=========================================================

* Product Page: https://www.creative-tim.com/product/argon-dashboard
* Copyright 2022 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://www.creative-tim.com/license)
* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('argon')); ?>/assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/img/logo.png')); ?>">
    <title>
        WEBSITE KTA
    </title>
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
    <!-- Nucleo Icons -->
    <link href="<?php echo e(asset('argon')); ?>/assets/css/nucleo-icons.css" rel="stylesheet" />
    <link href="<?php echo e(asset('argon')); ?>/assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- Font Awesome Icons -->
    <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
    <link href="<?php echo e(asset('argon')); ?>/assets/css/nucleo-svg.css" rel="stylesheet" />
    <!-- CSS Files -->
    <link id="pagestyle" href="<?php echo e(asset('argon')); ?>/assets/css/argon-dashboard.css?v=2.0.4" rel="stylesheet" />
</head>

<body class="">
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <main class="main-content  mt-0">
        <section>
            <div class="page-header min-vh-100">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-4 col-lg-5 col-md-7 d-flex flex-column mx-lg-0 mx-auto">
                            <div class="card card-plain">
                                <div class="card-header pb-0 text-start">
                                    <h4 class="font-weight-bolder">Sign In</h4>
                                    <p class="mb-0">Enter your email and password to sign in</p>
                                </div>
                                <div class="card-body">
                                    <form role="form" action="<?php echo e(url('/postlogin')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="mb-3">
                                            <input name="email" type="email" class="form-control form-control-lg"
                                                placeholder="Email" aria-label="Email">
                                        </div>
                                        <div class="mb-3">
                                            <input name="password" type="password" class="form-control form-control-lg"
                                                placeholder="Password" aria-label="Password">
                                        </div>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" id="rememberMe"
                                                name="remember">
                                            <label class="form-check-label" for="rememberMe">Remember me</label>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-lg btn-primary w-100 mt-4 mb-0">Sign
                                                in</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="card-footer text-center pt-0 px-lg-2 px-1">
                                    <p class="mb-4 text-sm mx-auto">
                                        Register
                                        <a href="<?php echo e(url('/form')); ?>" id="signUpLink"
                                            class="text-primary text-gradient font-weight-bold">Sign up</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div
                            class="col-6 d-lg-flex d-none h-100 my-auto pe-0 position-absolute top-0 end-0 text-center justify-content-center flex-column">
                            <div class="position-relative bg-gradient-primary h-100 m-3 px-7 border-radius-lg d-flex flex-column justify-content-center overflow-hidden"
                                style="background-image: url('argon/assets/img/bgp.jpg');background-size: cover;">
                                <span class="mask opacity-6" style="background-color: #86B6F6;"></span>
                                <h4 class="mt-5 text-white font-weight-bolder position-relative">WEBSITE OPREC ANGGOTA
                                </h4>
                                <p class="text-white position-relative">Forum OSIS Jawa Barat adalah organisasi binaan
                                    Dinas Pendidikan Provinsi Jawa Barat, Suatu wadah perkumpulan dan pengembangan
                                    kualitas diri para pelajar tingkat SMA/SMK/MA Se-Derajat yang tergabung dalam
                                    kepengurusan OSIS ditiap sekolah dengan Visi “menjadi inkubator pemimpin muda Jawa
                                    Barat berkarakter STRONG untuk Indonesia Emas Tahun 2045” FOJB ini Didirikan oleh 6
                                    anak muda hebat asli Jawa Barat sejak 5 Januari 2013 menjadikan FOJB sebagai
                                    Perkumpulan OSIS tertua di Indonesia. Proses pengukuhannya secara resmi dilakukan
                                    oleh Gubernur Jawa Barat saat itu. Dewasa kini Ikatan Alumni FOJB atau kerap disebut
                                    IKAL telah mencapai 15.000 anggota yang tersebar di berbagai posisi strategis di
                                    Jawa Barat bahkan Luar Negeri. Kedepannya Forum OSIS Jawa Barat akan terus berbenah
                                    hingga alumni-alumni nya dapat terus berkarya dan bermanfaat untuk
                                    masyarakat Indonesia..</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('argon')); ?>/assets/js/core/popper.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/assets/js/core/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/assets/js/plugins/smooth-scrollbar.min.js"></script>
    <script>
        var win = navigator.platform.indexOf('Win') > -1;
        if (win && document.querySelector('#sidenav-scrollbar')) {
            var options = {
                damping: '0.5'
            }
            Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
        }
    </script>
    <!-- Github buttons -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
    <script src="<?php echo e(asset('argon')); ?>/assets/js/argon-dashboard.min.js?v=2.0.4"></script>
    <script type="">// Mengambil tautan "Sign up" dengan ID atau kelas tertentu
        var signUpLink = document.getElementById('signUpLink');
        
        // Menambahkan event click pada tautan "Sign up"
        signUpLink.addEventListener('click', function() {
            // Menghapus data registerData dari sessionStorage
            sessionStorage.removeItem('registerData');
        });</script>
</body>

</html>
<?php /**PATH C:\Users\eherd\OneDrive\Documents\Project\kta\resources\views/auths/login.blade.php ENDPATH**/ ?>