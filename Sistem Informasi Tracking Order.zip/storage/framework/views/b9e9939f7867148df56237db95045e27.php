
<?php $__env->startSection('title', 'Data Pendaftaran'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/2.0.1/css/dataTables.dataTables.min.css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4 ">
        <div class="row">
            <div class="col-12 ">
                <div class="card mb-4 ">
                    <div class="card-header pb-0">
                        <div class="d-flex align-items-center">
                            <h6>Data Pendaftaran</h6>
                            <button type="button" class="btn btn-primary btn-sm ms-auto" data-bs-toggle="modal"
                                data-bs-target="#exampleModal">
                                Tambah Pendaftaran
                            </button>
                        </div>
                    </div>
                    <div class="card-body px-4 pt-0 pb-2">
                        <div class="table-responsive p-0">
                            <table id="myTable" class="table align-items-center mb-0">
                                <thead>
                                    <tr>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            Nama</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            Asal Sekolah</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            No Hp</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            email</th>
                                        <th
                                            class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            Status Pendaftaran</th>
                                        <th class="text-secondary opacity-7"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex px-2 py-1">
                                                    
                                                    <div class="d-flex flex-column justify-content-center">
                                                        <h6 class="mb-0 text-sm"><?php echo e($item->nama_siswa); ?></h6>
                                                        
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <p class="text-xs font-weight-bold mb-0"><?php echo e($item->nama_sekolah); ?></p>
                                                
                                            </td>
                                            <td>
                                                <p class="text-xs font-weight-bold mb-0"><?php echo e($item->hp); ?></p>
                                                
                                            </td>
                                            <td>
                                                <p class="text-xs font-weight-bold mb-0"><?php echo e($item->email); ?></p>
                                                
                                            </td>
                                            <td>
                                                <?php if($item->status_pendaftaran === 'Belum Terverifikasi'): ?>
                                                    <button type="button" class="btn btn-warning" data-bs-toggle="modal"
                                                        data-bs-target="#updatestatus<?php echo e($item->id); ?>">
                                                        <p class="text-xs font-weight-bold mb-0">
                                                            <?php echo e($item->status_pendaftaran); ?>

                                                        </p>
                                                    </button>
                                                <?php elseif($item->status_pendaftaran === 'Terverifikasi'): ?>
                                                    <button type="button" class="btn btn-success" data-bs-toggle="modal"
                                                        data-bs-target="#updatestatus<?php echo e($item->id); ?>">
                                                        <p class="text-xs font-weight-bold mb-0">
                                                            <?php echo e($item->status_pendaftaran); ?>

                                                        </p>
                                                    </button>
                                                <?php elseif($item->status_pendaftaran === 'Ditolak'): ?>
                                                    <button type="button" class="btn btn-danger" data-bs-toggle="modal"
                                                        data-bs-target="#updatestatus<?php echo e($item->id); ?>">
                                                        <p class="text-xs font-weight-bold mb-0">
                                                            <?php echo e($item->status_pendaftaran); ?>

                                                        </p>
                                                    </button>
                                                <?php endif; ?>


                                                
                                            </td>

                                            <td class="align-middle">
                                                
                                                <a type="button" class="" data-bs-toggle="modal"
                                                    data-bs-target="#update<?php echo e($item->id); ?>">
                                                    <i class="fas fa-edit text-success text-sm opacity-10"></i>
                                                </a>
                                                <a type="button" class="" data-bs-toggle="modal"
                                                    data-bs-target="#delete<?php echo e($item->id); ?>">
                                                    <i class="fas fa-trash fa-xs text-danger text-sm opacity-10"></i>
                                                </a>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="footer pt-3  ">
            <div class="container-fluid">
                <div class="row align-items-center justify-content-lg-between">
                    <div class="col-lg-6 mb-lg-0 mb-4">
                        <div class="copyright text-center text-sm text-muted text-lg-start">
                            ©
                            <script>
                                document.write(new Date().getFullYear())
                            </script>,
                            made with <i class="fa fa-heart"></i> by
                            <a href="https://www.creative-tim.com" class="font-weight-bold" target="_blank">Creative
                                Tim</a>
                            for a better web.
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <ul class="nav nav-footer justify-content-center justify-content-lg-end">
                            <li class="nav-item">
                                <a href="https://www.creative-tim.com" class="nav-link text-muted" target="_blank">Creative
                                    Tim</a>
                            </li>
                            <li class="nav-item">
                                <a href="https://www.creative-tim.com/presentation" class="nav-link text-muted"
                                    target="_blank">About Us</a>
                            </li>
                            <li class="nav-item">
                                <a href="https://www.creative-tim.com/blog" class="nav-link text-muted"
                                    target="_blank">Blog</a>
                            </li>
                            <li class="nav-item">
                                <a href="https://www.creative-tim.com/license" class="nav-link pe-0 text-muted"
                                    target="_blank">License</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <!-- Modal Create Data-->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Pendaftaran</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(url('/dashboard/pendaftaran/create')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <p class="text-uppercase text-sm">Program</p>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Pilihan 1</label>
                                    <select name="pilih_jurusan" id="" class="form-control form-select"
                                        aria-label=".form-select-sm example" value="<?php echo e(old('pilih_jurusan')); ?>">
                                        <option value="">Pilih</option>
                                        <option <?php if(old('pilih_jurusan') == 'Teknik Kendaraan Ringan Otomotif'): ?> selected <?php endif; ?>
                                            value="Teknik Kendaraan Ringan Otomotif">Teknik Kendaraan Ringan Otomotif
                                        </option>
                                        <option <?php if(old('pilih_jurusan') == 'Teknik Komputer dan Jaringan'): ?> selected <?php endif; ?>
                                            value="Teknik Komputer dan Jaringan">Teknik Komputer dan Jaringan
                                        </option>
                                        <option <?php if(old('pilih_jurusan') == 'Teknik Bisnis dan Sepeda Motor'): ?> selected <?php endif; ?>
                                            value="Teknik Bisnis dan Sepeda Motor">Teknik Bisnis dan Sepeda Motor</option>
                                        <option <?php if(old('pilih_jurusan') == 'Akuntansi dan Keuangan Lembaga'): ?> selected <?php endif; ?>
                                            value="Akuntansi dan Keuangan Lembaga">Akuntansi dan Keuangan Lembaga</option>
                                        <option <?php if(old('pilih_jurusan') == 'Perhotelan'): ?> selected <?php endif; ?> value="Perhotelan">
                                            Perhotelan
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['pilih_jurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Pilihan 2</label>
                                    <select name="pilih_jurusan1" id="" class="form-control form-select"
                                        aria-label=".form-select-sm example" value="<?php echo e(old('pilih_jurusan1')); ?>">
                                        <option value="">Pilih</option>
                                        <option <?php if(old('pilih_jurusan1') == 'Teknik Kendaraan Ringan Otomotif'): ?> selected <?php endif; ?>
                                            value="Teknik Kendaraan Ringan Otomotif">Teknik Kendaraan Ringan Otomotif
                                        </option>
                                        <option <?php if(old('pilih_jurusan1') == 'Teknik Komputer dan Jaringan'): ?> selected <?php endif; ?>
                                            value="Teknik Komputer dan Jaringan">Teknik Komputer dan Jaringan
                                        </option>
                                        <option <?php if(old('pilih_jurusan1') == 'Teknik Bisnis dan Sepeda Motor'): ?> selected <?php endif; ?>
                                            value="Teknik Bisnis dan Sepeda Motor">Teknik Bisnis dan Sepeda Motor</option>
                                        <option <?php if(old('pilih_jurusan1') == 'Akuntansi dan Keuangan Lembaga'): ?> selected <?php endif; ?>
                                            value="Akuntansi dan Keuangan Lembaga">Akuntansi dan Keuangan Lembaga</option>
                                        <option <?php if(old('pilih_jurusan1') == 'Perhotelan'): ?> selected <?php endif; ?> value="Perhotelan">
                                            Perhotelan
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['pilih_jurusan1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <hr class="horizontal dark">
                        <div class="row">
                            <p class="text-uppercase text-sm">Data Diri</p>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Nama Lengkap</label>
                                    <input name="nama_siswa" type="text" placeholder="Nama lengkap"
                                        class="form-control" value="<?php echo e(old('nama_siswa')); ?>">
                                    <?php $__errorArgs = ['nama_siswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">NIK</label>
                                    <input name="nik" type="text" placeholder="No nik" class="form-control"
                                        value="<?php echo e(old('nik')); ?>">
                                    <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Tempat
                                        Lahir</label>
                                    <input name="tempat_lahir" type="text" placeholder="Tempat lahir"
                                        class="form-control" value="<?php echo e(old('tempat_lahir')); ?>">
                                    <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Tanggal
                                        Lahir</label>
                                    <input name="tanggal_lahir" type="date" placeholder="Tanggal lahir"
                                        class="form-control" value="<?php echo e(old('tanggal_lahir')); ?>">
                                    <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Jenis
                                        Kelamin</label>
                                    <select name="jenis_kelamin" id="" class="form-control form-select">
                                        <option value="">Pilih</option>
                                        <option value="Laki-laki" <?php if(old('jenis_kelamin') == 'Laki-laki'): ?> selected <?php endif; ?>>
                                            Laki-laki
                                        </option>
                                        <option value="Perempuan" <?php if(old('jenis_kelamin') == 'Perempuan'): ?> selected <?php endif; ?>>
                                            Perempuan
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Agama</label>
                                    <select name="agama" id="" class="form-control form-select">
                                        <option value="">Pilih</option>
                                        <option value="Islam" <?php if(old('agama') == 'Islam'): ?> selected <?php endif; ?>>Islam
                                        </option>
                                        <option value="Kristen Khatolik"
                                            <?php if(old('agama') == 'Kristen Khatolik'): ?> selected <?php endif; ?>>
                                            Kristen Khatolik
                                        </option>
                                        <option value="Kristen Protestan"
                                            <?php if(old('agama') == 'Kristen Protestan'): ?> selected <?php endif; ?>>
                                            Kristen Protestan
                                        </option>
                                        <option value="Budha" <?php if(old('agama') == 'Budha'): ?> selected <?php endif; ?>>Budha
                                        </option>
                                        <option value="Hindu" <?php if(old('agama') == 'Hindu'): ?> selected <?php endif; ?>>Hindu
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Alat Transportasi ke
                                        Sekolah</label>
                                    <input name="transportasi" type="text" placeholder="Alat Transportasi ke Sekolah"
                                        class="form-control" value="<?php echo e(old('transportasi')); ?>">
                                    <?php $__errorArgs = ['transportasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Anak ke</label>
                                    <input name="anak_ke" type="text" placeholder="Anak ke" class="form-control"
                                        value="<?php echo e(old('anak_ke')); ?>">
                                    <?php $__errorArgs = ['anak_ke'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Tinggi Badan</label>
                                    <input name="t_badan" type="number" placeholder="Tinggi badan" class="form-control"
                                        value="<?php echo e(old('t_badan')); ?>">
                                    <?php $__errorArgs = ['t_badan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Berat Badan</label>
                                    <input name="b_badan" type="number" placeholder="Berat badan" class="form-control"
                                        value="<?php echo e(old('b_badan')); ?>">
                                    <?php $__errorArgs = ['b_badan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Ukuran Baju</label>
                                    <input name="ukuran_baju" type="text" placeholder="Ukuran baju"
                                        class="form-control" value="<?php echo e(old('ukuran_baju')); ?>">
                                    <?php $__errorArgs = ['ukuran_baju'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">KIP/PKH/KPS</label>
                                    <select name="kip" id="" class="form-control form-select">
                                        <option value="">Pilih</option>
                                        <option value="Ya" <?php if(old('kip') == 'Ya'): ?> selected <?php endif; ?>>Ya
                                        </option>
                                        <option value="Tidak" <?php if(old('kip') == 'Tidak'): ?> selected <?php endif; ?>>Tidak
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['kip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Bahasa sehari-hari</label>
                                    <input name="bahasa" type="text" placeholder="Bahasa sehari-hari"
                                        class="form-control" value="<?php echo e(old('bahasa')); ?>">
                                    <?php $__errorArgs = ['bahasa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Hobi</label>
                                    <input name="hobi" type="text" placeholder="Hobi" class="form-control"
                                        value="<?php echo e(old('hobi')); ?>">
                                    <?php $__errorArgs = ['hobi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Cita-cita</label>
                                    <input name="cita_cita" type="text" placeholder="Cita - cita"
                                        class="form-control" value="<?php echo e(old('cita_cita')); ?>">
                                    <?php $__errorArgs = ['cita_cita'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input"  class="form-control-label">No
                                        Hp</label>
                                    <input name="hp" placeholder="No Hp" class="form-control" type="text"
                                        value="<?php echo e(old('hp')); ?>">
                                    <?php $__errorArgs = ['hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" 
                                        class="form-control-label">Email</label>
                                    <input name="email" placeholder="Email" class="form-control" type="email"
                                        value="<?php echo e(old('email')); ?>">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Jenis Pendaftaran</label>
                                    <select name="jenis_pendaftaran" id="" class="form-control form-select"
                                        value="<?php echo e(old('jenis_pendaftaran')); ?>">
                                        <option value="">Pilih</option>
                                        <option <?php if(old('jenis_pendaftaran') == 'Baru'): ?> selected <?php endif; ?> value="Baru">Baru
                                        </option>
                                        <option <?php if(old('jenis_pendaftaran') == 'Pindah'): ?> selected <?php endif; ?> value="Pindah">Pindah
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['jenis_pendaftaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <hr class="horizontal dark">
                        <p class="text-uppercase text-sm">Data Alamat</p>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Alamat</label>
                                    <textarea name="alamat" id="" class="form-control"><?php echo e(old('alamat')); ?></textarea>
                                    <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Provinsi</label>
                                    <select name="provinsi" id="provinsi" class="form-control form-select">
                                        <option value="">Pilih Provinsi</option>
                                    </select>
                                    <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Kota atau Kabupaten</label>
                                    <select name="kota_kabupaten" id="kota" class="form-control form-select">
                                        <option value="">Pilih Kab/Kota</option>
                                    </select>
                                    <?php $__errorArgs = ['kota_kabupaten'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Kecamatan
                                        address</label>
                                    <select name="kecamatan" id="kecamatan" class="form-control form-select">
                                        <option value="">Pilih Kecamatan</option>
                                    </select>
                                    <?php $__errorArgs = ['kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Kelurahan</label>
                                    <select name="kelurahan" id="kelurahan" class="form-control form-select">
                                        <option value="">Pilih Kelurahan</option>
                                    </select>
                                    <?php $__errorArgs = ['kelurahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Kode Pos</label>
                                    <input name="kode_pos" type="text" placeholder="Kode pos" class="form-control"
                                        value="<?php echo e(old('kode_pos')); ?>">
                                    <?php $__errorArgs = ['kode_pos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <hr class="horizontal dark">
                        <p class="text-uppercase text-sm">Data Kelulusan SMP</p>
                        <div class="row">
                            <div class="col-md-6">
                                <label for="" class="form-control-label">Asal Sekolah</label>
                                <input name="nama_sekolah" type="text" placeholder="Asal sekolah"
                                    class="form-control" value="<?php echo e(old('nama_sekolah')); ?>">
                                <?php $__errorArgs = ['nama_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <label for="" class="form-control-label">Alamat sekolah</label>
                                <textarea name="alamat_sekolah_asal" id="" class="form-control"><?php echo e(old('alamat_sekolah_asal')); ?></textarea>
                                <?php $__errorArgs = ['alamat_sekolah_asal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Kota/Kabupaten</label>
                                <input name="kota_sekolah_asal" type="text" placeholder="Kota Asal sekolah"
                                    class="form-control" value="<?php echo e(old('kota_sekolah_asal')); ?>">
                                <?php $__errorArgs = ['kota_sekolah_asal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Tahun lulus</label>
                                <input name="tahun_lulus" type="number" placeholder="Tahun Lulus" class="form-control"
                                    value="<?php echo e(old('tahun_lulus')); ?>">
                                <?php $__errorArgs = ['tahun_lulus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Tanggal ijazah</label>
                                <input name="tanggal_ijazah" type="date" placeholder="Tanggal ijazah"
                                    class="form-control" value="<?php echo e(old('tanggal_ijazah')); ?>">
                                <?php $__errorArgs = ['tanggal_ijazah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Nomor peserta UN</label>
                                <input name="nomor_peserta_un" type="text" placeholder="Nomor peserta UN"
                                    class="form-control" value="<?php echo e(old('nomor_peserta_un')); ?>">
                                <?php $__errorArgs = ['nomor_peserta_un'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">NISN</label>
                                <input name="nisn" type="text" placeholder="NISN" class="form-control"
                                    value="<?php echo e(old('nisn')); ?>">
                                <?php $__errorArgs = ['nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Nomor seri SKHUN</label>
                                <input name="nomor_skhun" type="text" placeholder="Nomor Seri SKHUN"
                                    class="form-control" value="<?php echo e(old('nomor_skhun')); ?>">
                                <?php $__errorArgs = ['nomor_skhun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Nomor seri Ijazah</label>
                                <input name="nomor_ijazah" type="text" placeholder="Nomor Seri Ijazah"
                                    class="form-control" value="<?php echo e(old('nomor_ijazah')); ?>">
                                <?php $__errorArgs = ['nomor_ijazah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <hr class="horizontal dark">
                        <p class="text-uppercase text-sm">Data Orang Tua</p>
                        <div class="row">
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Nama Lengkap Ayah</label>
                                <input name="nama_ayah" type="text" placeholder="Nama lengkap ayah"
                                    class="form-control" value="<?php echo e(old('nama_ayah')); ?>">
                                <?php $__errorArgs = ['nama_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">No KTP</label>
                                <input name="no_ktp_ayah" type="text" placeholder="Pekerjaan ayah"
                                    class="form-control"value="<?php echo e(old('no_ktp_ayah')); ?>">
                                <?php $__errorArgs = ['no_ktp_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Tempat Lahir</label>
                                <input name="tempat_lahir_ayah" type="text" placeholder="Tempat Lahir"
                                    class="form-control" value="<?php echo e(old('tempat_lahir_ayah')); ?>">
                                <?php $__errorArgs = ['tempat_lahir_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Tanggal Lahir</label>
                                <input name="tanggal_lahir_ayah" type="date" placeholder="Tanggal Lahir"
                                    class="form-control"value="<?php echo e(old('tanggal_lahir_ayah')); ?>">
                                <?php $__errorArgs = ['tanggal_lahir_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Gol Darah</label>
                                <input name="gol_darah_ayah" type="text" placeholder="Gol Darah"
                                    class="form-control"value="<?php echo e(old('gol_darah_ayah')); ?>">
                                <?php $__errorArgs = ['gol_darah_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Pekerjaan Ayah</label>
                                <select name="pekerjaan_ayah" id="" class="form-control form-select"
                                    value="<?php echo e(old('pekerjaan_ayah')); ?>">
                                    <option value="">pilih</option>
                                    <option <?php if(old('pekerjaan_ayah') == 'PNS'): ?> selected <?php endif; ?> value="PNS">PNS</option>
                                    <option <?php if(old('pekerjaan_ayah') == 'BUMN/D'): ?> selected <?php endif; ?> value="BUMN/D">BUMN/D
                                    </option>
                                    <option <?php if(old('pekerjaan_ayah') == 'Swasta'): ?> selected <?php endif; ?> value="Swasta">Swasta
                                    </option>
                                    <option <?php if(old('pekerjaan_ayah') == 'Polri'): ?> selected <?php endif; ?> value="Polri">Polri
                                    </option>
                                    <option <?php if(old('pekerjaan_ayah') == 'TNI'): ?> selected <?php endif; ?> value="TNI">TNI</option>
                                </select>
                                <?php $__errorArgs = ['pekerjaan_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Alamat Tempat Kerja</label>
                                <textarea name="alamat_pekerjaan_ayah" type="text" placeholder="Alamat Kerja" class="form-control"
                                    value="<?php echo e(old('alamat_pekerjaan_ayah')); ?>"><?php echo e(old('alamat_pekerjaan_ayah')); ?></textarea>
                                <?php $__errorArgs = ['alamat_pekerjaan_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Pendidikan Ayah</label>
                                <select name="pendidikan_ayah" id="" class="form-control form-select"
                                    value="<?php echo e(old('pendidikan_ayah')); ?>">
                                    <option value="">pilih
                                    </option>
                                    <option <?php if(old('pendidikan_ayah') == 'SD'): ?> selected <?php endif; ?> value="SD">SD</option>
                                    <option <?php if(old('pendidikan_ayah') == 'SMP'): ?> selected <?php endif; ?> value="SMP">SMP</option>
                                    <option <?php if(old('pendidikan_ayah') == 'SMA'): ?> selected <?php endif; ?> value="SMA">SMA</option>
                                    <option <?php if(old('pendidikan_ayah') == 'D I'): ?> selected <?php endif; ?> value="D I">D I</option>
                                    <option <?php if(old('pendidikan_ayah') == 'D III'): ?> selected <?php endif; ?> value="D III">D III
                                    </option>
                                    <option <?php if(old('pendidikan_ayah') == 'S1'): ?> selected <?php endif; ?> value="S1">S1</option>
                                    <option <?php if(old('pendidikan_ayah') == 'S2'): ?> selected <?php endif; ?> value="S2">S2</option>
                                    <option <?php if(old('pendidikan_ayah') == 'S3'): ?> selected <?php endif; ?> value="S3">S3</option>
                                </select>
                                <?php $__errorArgs = ['pendidikan_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Penghasilan Ayah</label>
                                <select name="penghasilan_ayah" id="" class="form-control form-select"
                                    value="<?php echo e(old('penghasilan_ayah')); ?>">
                                    <option value="">pilih</option>
                                    <option <?php if(old('penghasilan_ayah') == '< Rp. 1.00.000'): ?> selected <?php endif; ?> value="< Rp. 1.00.000">
                                        < Rp. 1.00.000</option>
                                    <option <?php if(old('penghasilan_ayah') == 'Rp. 1.00.000 - Rp. 250.000'): ?> selected <?php endif; ?>
                                        value="Rp. 1.00.000 - Rp. 250.000">Rp. 1.00.000 - Rp. 250.000</option>
                                    <option <?php if(old('penghasilan_ayah') == 'Rp. 250.000 - Rp. 450.000'): ?> selected <?php endif; ?>
                                        value="Rp. 250.000 - Rp. 450.000">Rp. 250.000 - Rp. 450.000</option>
                                    <option <?php if(old('penghasilan_ayah') == 'Rp. 450.000 - Rp. 1.000.000'): ?> selected <?php endif; ?>
                                        value="Rp. 450.000 - Rp. 1.000.000">Rp. 450.000 - Rp. 1.000.000</option>
                                    <option <?php if(old('penghasilan_ayah') == 'Rp. 1.000.000 - Rp. 1.500.000'): ?> selected <?php endif; ?>
                                        value="Rp. 1.000.000 - Rp. 1.500.000">Rp. 1.000.000 - Rp. 1.500.000</option>
                                    <option <?php if(old('penghasilan_ayah') == 'Rp. 1.500.000 - Rp. 2.000.000'): ?> selected <?php endif; ?>
                                        value="Rp. 1.500.000 - Rp. 2.000.000">Rp. 1.500.000 - Rp. 2.000.000</option>
                                    <option <?php if(old('penghasilan_ayah') == '> Rp. 2.000.000'): ?> selected <?php endif; ?> value="> Rp. 2.000.000"> >
                                        Rp. 2.000.000</option>
                                </select>
                                <?php $__errorArgs = ['penghasilan_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Kode Pos</label>
                                <input name="kode_pos_ayah" type="text" placeholder="Kode pos"
                                    class="form-control"value="<?php echo e(old('kode_pos_ayah')); ?>">
                                <?php $__errorArgs = ['kode_pos_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">No Hp</label>
                                <input name="nohp_ayah" type="text" placeholder="No hp" class="form-control"
                                    value="<?php echo e(old('nohp_ayah')); ?>">
                                <?php $__errorArgs = ['nohp_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <hr class="horizontal dark">
                        <div class="row">
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Nama Ibu Kandung</label>
                                <input name="nama_ayah" type="text" placeholder="Nama lengkap ayah"
                                    class="form-control" value="<?php echo e(old('nama_ayah')); ?>">
                                <?php $__errorArgs = ['nama_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">No KTP</label>
                                <input name="no_ktp_ibu" type="text" placeholder="No KTP"
                                    class="form-control"value="<?php echo e(old('no_ktp_ibu')); ?>">
                                <?php $__errorArgs = ['no_ktp_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Tempat Lahir</label>
                                <input name="tempat_lahir_ibu" type="text" placeholder="Tempat Lahir"
                                    class="form-control" value="<?php echo e(old('tempat_lahir_ibu')); ?>">
                                <?php $__errorArgs = ['tempat_lahir_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Tanggal Lahir</label>
                                <input name="tanggal_lahir_ibu" type="date" placeholder="Tanggal Lahir"
                                    class="form-control"value="<?php echo e(old('tanggal_lahir_ibu')); ?>">
                                <?php $__errorArgs = ['tanggal_lahir_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Gol Darah</label>
                                <input name="gol_darah_ibu" type="text" placeholder="Gol Darah"
                                    class="form-control"value="<?php echo e(old('gol_darah_ibu')); ?>">
                                <?php $__errorArgs = ['gol_darah_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Pekerjaan Ibu</label>
                                <select name="pekerjaan_ibu" id="" class="form-control form-select"
                                    value="<?php echo e(old('pekerjaan_ibu')); ?>">
                                    <option value="">pilih</option>
                                    <option <?php if(old('pekerjaan_ibu') == 'PNS'): ?> selected <?php endif; ?> value="PNS">PNS</option>
                                    <option <?php if(old('pekerjaan_ibu') == 'BUMN/D'): ?> selected <?php endif; ?> value="BUMN/D">BUMN/D
                                    </option>
                                    <option <?php if(old('pekerjaan_ibu') == 'Swasta'): ?> selected <?php endif; ?> value="Swasta">Swasta
                                    </option>
                                    <option <?php if(old('pekerjaan_ibu') == 'Polri'): ?> selected <?php endif; ?> value="Polri">Polri
                                    </option>
                                    <option <?php if(old('pekerjaan_ibu') == 'TNI'): ?> selected <?php endif; ?> value="TNI">TNI</option>
                                </select>
                                <?php $__errorArgs = ['pekerjaan_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Alamat Tempat Kerja</label>
                                <textarea name="alamat_pekerjaan_ibu" type="text" placeholder="Alamat Kerja" class="form-control"
                                    value="<?php echo e(old('alamat_pekerjaan_ibu')); ?>"><?php echo e(old('alamat_pekerjaan_ibu')); ?></textarea>
                                <?php $__errorArgs = ['alamat_pekerjaan_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Pendidikan Ibu</label>
                                <select name="pendidikan_ibu" id="" class="form-control form-select"
                                    value="<?php echo e(old('pendidikan_ibu')); ?>">
                                    <option value="">pilih
                                    </option>
                                    <option <?php if(old('pendidikan_ibu') == 'SD'): ?> selected <?php endif; ?> value="SD">SD</option>
                                    <option <?php if(old('pendidikan_ibu') == 'SMP'): ?> selected <?php endif; ?> value="SMP">SMP</option>
                                    <option <?php if(old('pendidikan_ibu') == 'SMA'): ?> selected <?php endif; ?> value="SMA">SMA</option>
                                    <option <?php if(old('pendidikan_ibu') == 'D I'): ?> selected <?php endif; ?> value="D I">D I</option>
                                    <option <?php if(old('pendidikan_ibu') == 'D III'): ?> selected <?php endif; ?> value="D III">D III
                                    </option>
                                    <option <?php if(old('pendidikan_ibu') == 'S1'): ?> selected <?php endif; ?> value="S1">S1</option>
                                    <option <?php if(old('pendidikan_ibu') == 'S2'): ?> selected <?php endif; ?> value="S2">S2</option>
                                    <option <?php if(old('pendidikan_ibu') == 'S3'): ?> selected <?php endif; ?> value="S3">S3</option>
                                </select>
                                <?php $__errorArgs = ['pendidikan_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Penghasilan Ibu</label>
                                <select name="penghasilan_ibu" id="" class="form-control form-select"
                                    value="<?php echo e(old('penghasilan_ibu')); ?>">
                                    <option value="">pilih</option>
                                    <option <?php if(old('penghasilan_ibu') == '< Rp. 1.00.000'): ?> selected <?php endif; ?> value="< Rp. 1.00.000">
                                        < Rp. 1.00.000</option>
                                    <option <?php if(old('penghasilan_ibu') == 'Rp. 1.00.000 - Rp. 250.000'): ?> selected <?php endif; ?>
                                        value="Rp. 1.00.000 - Rp. 250.000">Rp. 1.00.000 - Rp. 250.000</option>
                                    <option <?php if(old('penghasilan_ibu') == 'Rp. 250.000 - Rp. 450.000'): ?> selected <?php endif; ?>
                                        value="Rp. 250.000 - Rp. 450.000">Rp. 250.000 - Rp. 450.000</option>
                                    <option <?php if(old('penghasilan_ibu') == 'Rp. 450.000 - Rp. 1.000.000'): ?> selected <?php endif; ?>
                                        value="Rp. 450.000 - Rp. 1.000.000">Rp. 450.000 - Rp. 1.000.000</option>
                                    <option <?php if(old('penghasilan_ibu') == 'Rp. 1.000.000 - Rp. 1.500.000'): ?> selected <?php endif; ?>
                                        value="Rp. 1.000.000 - Rp. 1.500.000">Rp. 1.000.000 - Rp. 1.500.000</option>
                                    <option <?php if(old('penghasilan_ibu') == 'Rp. 1.500.000 - Rp. 2.000.000'): ?> selected <?php endif; ?>
                                        value="Rp. 1.500.000 - Rp. 2.000.000">Rp. 1.500.000 - Rp. 2.000.000</option>
                                    <option <?php if(old('penghasilan_ibu') == '> Rp. 2.000.000'): ?> selected <?php endif; ?> value="> Rp. 2.000.000"> >
                                        Rp. 2.000.000</option>
                                </select>
                                <?php $__errorArgs = ['penghasilan_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">Kode Pos</label>
                                <input name="kode_pos_ibu" type="text" placeholder="Kode pos"
                                    class="form-control"value="<?php echo e(old('kode_pos_ibu')); ?>">
                                <?php $__errorArgs = ['kode_pos_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4">
                                <label for="" class="form-control-label">No Hp</label>
                                <input name="nohp_ibu" type="text" placeholder="No hp" class="form-control"
                                    value="<?php echo e(old('nohp_ibu')); ?>">
                                <?php $__errorArgs = ['nohp_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <hr class="horizontal dark">
                        <p class="text-uppercase text-sm">File</p>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Pas Foto 3x4</label>
                                    <input name="pas_foto" class="form-control" type="file">
                                </div>
                            </div>
                        </div>
                        <hr class="horizontal dark">
                        
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <!-- End Modal Create Data-->

    <!-- Modal Delete Data-->
    <?php $__currentLoopData = $pendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="delete<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Delete Data <?php echo e($item->nama_siswa); ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(url('/dashboard/pendaftaran/destroy/' . $item->id)); ?>" method="Post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <p>apakah anda yakin ingin menghapus data ini?</p>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Delete</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- End Modal Delete Data-->

    <!-- Modal Update Data-->
    <?php $__currentLoopData = $pendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="update<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Update Pendaftaran</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(url('/dashboard/pendaftaran/update/' . $item->id)); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <p class="text-uppercase text-sm">Program</p>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Pilihan 1</label>
                                        <select name="pilih_jurusan" id="" class="form-control form-select"
                                            aria-label=".form-select-sm example">
                                            <option value="">Pilih</option>
                                            <option <?php if($item->pilih_jurusan == 'Teknik Kendaraan Ringan Otomotif'): ?> selected <?php endif; ?>
                                                value="Teknik Kendaraan Ringan Otomotif">Teknik Kendaraan Ringan Otomotif
                                            </option>
                                            <option <?php if($item->pilih_jurusan == 'Teknik Komputer dan Jaringan'): ?> selected <?php endif; ?>
                                                value="Teknik Komputer dan Jaringan">Teknik Komputer dan Jaringan
                                            </option>
                                            <option <?php if($item->pilih_jurusan == 'Teknik Bisnis dan Sepeda Motor'): ?> selected <?php endif; ?>
                                                value="Teknik Bisnis dan Sepeda Motor">Teknik Bisnis dan Sepeda Motor
                                            </option>
                                            <option <?php if($item->pilih_jurusan == 'Akuntansi dan Keuangan Lembaga'): ?> selected <?php endif; ?>
                                                value="Akuntansi dan Keuangan Lembaga">Akuntansi dan Keuangan Lembaga
                                            </option>
                                            <option <?php if($item->pilih_jurusan == 'Perhotelan'): ?> selected <?php endif; ?> value="Perhotelan">
                                                Perhotelan
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['pilih_jurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Pilihan 2</label>
                                        <select name="pilih_jurusan1" id="" class="form-control form-select"
                                            aria-label=".form-select-sm example" value="<?php echo e(old('pilih_jurusan1')); ?>">
                                            <option value="">Pilih</option>
                                            <option <?php if($item->pilih_jurusan1 == 'Teknik Kendaraan Ringan Otomotif'): ?> selected <?php endif; ?>
                                                value="Teknik Kendaraan Ringan Otomotif">Teknik Kendaraan Ringan Otomotif
                                            </option>
                                            <option <?php if($item->pilih_jurusan1 == 'Teknik Komputer dan Jaringan'): ?> selected <?php endif; ?>
                                                value="Teknik Komputer dan Jaringan">Teknik Komputer dan Jaringan
                                            </option>
                                            <option <?php if($item->pilih_jurusan1 == 'Teknik Bisnis dan Sepeda Motor'): ?> selected <?php endif; ?>
                                                value="Teknik Bisnis dan Sepeda Motor">Teknik Bisnis dan Sepeda Motor
                                            </option>
                                            <option <?php if($item->pilih_jurusan1 == 'Akuntansi dan Keuangan Lembaga'): ?> selected <?php endif; ?>
                                                value="Akuntansi dan Keuangan Lembaga">Akuntansi dan Keuangan Lembaga
                                            </option>
                                            <option <?php if($item->pilih_jurusan1 == 'Perhotelan'): ?> selected <?php endif; ?> value="Perhotelan">
                                                Perhotelan
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['pilih_jurusan1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <hr class="horizontal dark">
                            <div class="row">
                                <p class="text-uppercase text-sm">Data Diri</p>
                                
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Nama Lengkap</label>
                                        <input name="nama_siswa" type="text" placeholder="Nama lengkap"
                                            class="form-control" value="<?php echo e($item->nama_siswa); ?>">
                                        <?php $__errorArgs = ['nama_siswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">NIK</label>
                                        <input name="nik" type="text" placeholder="No nik" class="form-control"
                                            value="<?php echo e($item->nik); ?>">
                                        <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Tempat
                                            Lahir</label>
                                        <input name="tempat_lahir" type="text" placeholder="Tempat lahir"
                                            class="form-control" value="<?php echo e($item->tempat_lahir); ?>">
                                        <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Tanggal
                                            Lahir</label>
                                        <input name="tanggal_lahir" type="date" placeholder="Tanggal lahir"
                                            class="form-control" value="<?php echo e($item->tanggal_lahir); ?>">
                                        <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Jenis
                                            Kelamin</label>
                                        <select name="jenis_kelamin" id="" class="form-control form-select">
                                            <option value="">Pilih</option>
                                            <option value="Laki-laki" <?php if($item->jenis_kelamin == 'Laki-laki'): ?> selected <?php endif; ?>>
                                                Laki-laki
                                            </option>
                                            <option value="Perempuan" <?php if($item->jenis_kelamin == 'Perempuan'): ?> selected <?php endif; ?>>
                                                Perempuan
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Agama</label>
                                        <select name="agama" id="" class="form-control form-select">
                                            <option value="">Pilih</option>
                                            <option value="Islam" <?php if($item->agama == 'Islam'): ?> selected <?php endif; ?>>
                                                Islam
                                            </option>
                                            <option value="Kristen Khatolik"
                                                <?php if($item->agama == 'Kristen Khatolik'): ?> selected <?php endif; ?>>
                                                Kristen Khatolik
                                            </option>
                                            <option value="Kristen Protestan"
                                                <?php if($item->agama == 'Kristen Protestan'): ?> selected <?php endif; ?>>
                                                Kristen Protestan
                                            </option>
                                            <option value="Budha" <?php if($item->agama == 'Budha'): ?> selected <?php endif; ?>>
                                                Budha
                                            </option>
                                            <option value="Hindu" <?php if($item->agama == 'Hindu'): ?> selected <?php endif; ?>>
                                                Hindu
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Alat Transportasi ke
                                            Sekolah</label>
                                        <input name="transportasi" type="text"
                                            placeholder="Alat Transportasi ke Sekolah" class="form-control"
                                            value="<?php echo e($item->transportasi); ?>">
                                        <?php $__errorArgs = ['transportasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Anak ke</label>
                                        <input name="anak_ke" type="text" placeholder="Anak ke" class="form-control"
                                            value="<?php echo e($item->anak_ke); ?>">
                                        <?php $__errorArgs = ['anak_ke'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Tinggi Badan</label>
                                        <input name="t_badan" type="number" placeholder="Tinggi badan"
                                            class="form-control" value="<?php echo e($item->t_badan); ?>">
                                        <?php $__errorArgs = ['t_badan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Berat Badan</label>
                                        <input name="b_badan" type="number" placeholder="Berat badan"
                                            class="form-control" value="<?php echo e($item->b_badan); ?>">
                                        <?php $__errorArgs = ['b_badan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Ukuran Baju</label>
                                        <input name="ukuran_baju" type="text" placeholder="Ukuran baju"
                                            class="form-control" value="<?php echo e($item->ukuran_baju); ?>">
                                        <?php $__errorArgs = ['ukuran_baju'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">KIP/PKH/KPS</label>
                                        <select name="kip" id="" class="form-control form-select">
                                            <option value="">Pilih</option>
                                            <option value="Ya" <?php if($item->kip == 'Ya'): ?> selected <?php endif; ?>>Ya
                                            </option>
                                            <option value="Tidak" <?php if($item->kip == 'Tidak'): ?> selected <?php endif; ?>>
                                                Tidak
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['kip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Bahasa
                                            sehari-hari</label>
                                        <input name="bahasa" type="text" placeholder="Bahasa sehari-hari"
                                            class="form-control" value="<?php echo e($item->bahasa); ?>">
                                        <?php $__errorArgs = ['bahasa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Hobi</label>
                                        <input name="hobi" type="text" placeholder="Hobi" class="form-control"
                                            value="<?php echo e($item->hobi); ?>">
                                        <?php $__errorArgs = ['hobi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Cita-cita</label>
                                        <input name="cita_cita" type="text" placeholder="Cita - cita"
                                            class="form-control" value="<?php echo e($item->cita_cita); ?>">
                                        <?php $__errorArgs = ['cita_cita'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" placeholder="No Hp" class="form-control-label">No
                                            Hp</label>
                                        <input name="hp" class="form-control" type="text"
                                            value="<?php echo e($item->hp); ?>">
                                        <?php $__errorArgs = ['hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" placeholder="Email"
                                            class="form-control-label">Email</label>
                                        <input name="email" class="form-control" type="email"
                                            value="<?php echo e($item->email); ?>">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Jenis
                                            Pendaftaran</label>
                                        <select name="jenis_pendaftaran" id="" class="form-control form-select"
                                            value="<?php echo e(old('jenis_pendaftaran')); ?>">
                                            <option value="">Pilih</option>
                                            <option <?php if($item->jenis_pendaftaran == 'Baru'): ?> selected <?php endif; ?> value="Baru">Baru
                                            </option>
                                            <option <?php if($item->jenis_pendaftaran == 'Pindah'): ?> selected <?php endif; ?> value="Pindah">
                                                Pindah
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['jenis_pendaftaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <hr class="horizontal dark">
                            <p class="text-uppercase text-sm">Data Alamat</p>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Alamat</label>
                                        <textarea name="alamat" id="" class="form-control"><?php echo e($item->alamat); ?></textarea>
                                        <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Provinsi</label>
                                        <input type="hidden" id="provinsiName" value="<?php echo e($item->provinsi); ?>">
                                        <select name="provinsi" id="provinsi1" class="form-control form-select">
                                            <option value="">Pilih Provinsi</option>
                                        </select>
                                        <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Kota atau
                                            Kabupaten</label>
                                        <input type="hidden" id="kotaName" value="<?php echo e($item->kota_kabupaten); ?>">

                                        <select name="kota_kabupaten" id="kota1" class="form-control form-select">
                                            <option value="">Pilih Kota/Kabupaten
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['kota_kabupaten'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Kecamatan
                                        </label>
                                        <input type="hidden" id="kecamatanName" value="<?php echo e($item->kecamatan); ?>">
                                        <select name="kecamatan" id="kecamatan1" class="form-control form-select">
                                            <option value="">Pilih Kecamatan</option>
                                        </select>
                                        <?php $__errorArgs = ['kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Kelurahan</label>
                                        <input type="hidden" id="kelurahanName" value="<?php echo e($item->kelurahan); ?>">
                                        <select name="kelurahan" id="kelurahan1" class="form-control form-select">
                                            <option value="">Pilih Kelurahan</option>
                                        </select>
                                        <?php $__errorArgs = ['kelurahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Kode Pos</label>
                                        <input name="kode_pos" type="text" placeholder="Kode pos"
                                            class="form-control" value="<?php echo e($item->kode_pos); ?>">
                                        <?php $__errorArgs = ['kode_pos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <hr class="horizontal dark">
                            <p class="text-uppercase text-sm">Data Kelulusan SMP</p>
                            <div class="row">
                                <div class="col-md-6">
                                    <label for="" class="form-control-label">Asal Sekolah</label>
                                    <input name="nama_sekolah" type="text" placeholder="Asal sekolah"
                                        class="form-control" value="<?php echo e($item->nama_sekolah); ?>">
                                    <?php $__errorArgs = ['nama_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6">
                                    <label for="" class="form-control-label">Alamat sekolah</label>
                                    <textarea name="alamat_sekolah_asal" id="" class="form-control"><?php echo e($item->alamat_sekolah_asal); ?></textarea>
                                    <?php $__errorArgs = ['alamat_sekolah_asal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Kota/Kabupaten</label>
                                    <input name="kota_sekolah_asal" type="text" placeholder="Kota Asal sekolah"
                                        class="form-control" value="<?php echo e($item->kota_sekolah_asal); ?>">
                                    <?php $__errorArgs = ['kota_sekolah_asal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Tahun lulus</label>
                                    <input name="tahun_lulus" type="number" placeholder="Tahun Lulus"
                                        class="form-control" value="<?php echo e($item->tahun_lulus); ?>">
                                    <?php $__errorArgs = ['tahun_lulus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Tanggal ijazah</label>
                                    <input name="tanggal_ijazah" type="date" placeholder="Tanggal ijazah"
                                        class="form-control" value="<?php echo e($item->tanggal_ijazah); ?>">
                                    <?php $__errorArgs = ['tanggal_ijazah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Nomor peserta UN</label>
                                    <input name="nomor_peserta_un" type="text" placeholder="Nomor peserta UN"
                                        class="form-control" value="<?php echo e($item->nomor_peserta_un); ?>">
                                    <?php $__errorArgs = ['nomor_peserta_un'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">NISN</label>
                                    <input name="nisn" type="text" placeholder="NISN" class="form-control"
                                        value="<?php echo e($item->nisn); ?>">
                                    <?php $__errorArgs = ['nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Nomor seri SKHUN</label>
                                    <input name="nomor_skhun" type="text" placeholder="Nomor Seri SKHUN"
                                        class="form-control" value="<?php echo e($item->nomor_skhun); ?>">
                                    <?php $__errorArgs = ['nomor_skhun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Nomor seri Ijazah</label>
                                    <input name="nomor_ijazah" type="text" placeholder="Nomor Seri Ijazah"
                                        class="form-control" value="<?php echo e($item->nomor_ijazah); ?>">
                                    <?php $__errorArgs = ['nomor_ijazah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <hr class="horizontal dark">
                            <p class="text-uppercase text-sm">Data Orang Tua</p>
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Nama Ayah Kandung</label>
                                    <input name="nama_ayah" type="text" placeholder="Nama Ayah Kandung"
                                        class="form-control" value="<?php echo e($item->nama_ayah); ?>">
                                    <?php $__errorArgs = ['nama_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">No KTP</label>
                                    <input name="no_ktp_ayah" type="text" placeholder="Pekerjaan ayah"
                                        class="form-control"value="<?php echo e($item->no_ktp_ayah); ?>">
                                    <?php $__errorArgs = ['no_ktp_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Tempat Lahir</label>
                                    <input name="tempat_lahir_ayah" type="text" placeholder="Tempat Lahir"
                                        class="form-control" value="<?php echo e($item->tempat_lahir_ayah); ?>">
                                    <?php $__errorArgs = ['tempat_lahir_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Tanggal Lahir</label>
                                    <input name="tanggal_lahir_ayah" type="date" placeholder="Tanggal Lahir"
                                        class="form-control"value="<?php echo e($item->tanggal_lahir_ayah); ?>">
                                    <?php $__errorArgs = ['tanggal_lahir_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Gol Darah</label>
                                    <input name="gol_darah_ayah" type="text" placeholder="Gol Darah"
                                        class="form-control"value="<?php echo e($item->gol_darah_ayah); ?>">
                                    <?php $__errorArgs = ['gol_darah_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Pekerjaan Ayah</label>
                                    <select name="pekerjaan_ayah" id="" class="form-control form-select"
                                        value="<?php echo e(old('pekerjaan_ayah')); ?>">
                                        <option value="">pilih</option>
                                        <option <?php if($item->pekerjaan_ayah == 'PNS'): ?> selected <?php endif; ?> value="PNS">PNS
                                        </option>
                                        <option <?php if($item->pekerjaan_ayah == 'BUMN/D'): ?> selected <?php endif; ?> value="BUMN/D">BUMN/D
                                        </option>
                                        <option <?php if($item->pekerjaan_ayah == 'Swasta'): ?> selected <?php endif; ?> value="Swasta">Swasta
                                        </option>
                                        <option <?php if($item->pekerjaan_ayah == 'Polri'): ?> selected <?php endif; ?> value="Polri">Polri
                                        </option>
                                        <option <?php if($item->pekerjaan_ayah == 'TNI'): ?> selected <?php endif; ?> value="TNI">TNI
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['pekerjaan_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Alamat Tempat Kerja</label>
                                    <textarea name="alamat_pekerjaan_ayah" type="text" placeholder="Alamat Kerja" class="form-control"
                                        value="<?php echo e(old('alamat_pekerjaan_ayah')); ?>"><?php echo e($item->alamat_pekerjaan_ayah); ?></textarea>
                                    <?php $__errorArgs = ['alamat_pekerjaan_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Pendidikan Ayah</label>
                                    <select name="pendidikan_ayah" id="" class="form-control form-select"
                                        value="<?php echo e(old('pendidikan_ayah')); ?>">
                                        <option value="">pilih
                                        </option>
                                        <option <?php if($item->pendidikan_ayah == 'SD'): ?> selected <?php endif; ?> value="SD">SD
                                        </option>
                                        <option <?php if($item->pendidikan_ayah == 'SMP'): ?> selected <?php endif; ?> value="SMP">SMP
                                        </option>
                                        <option <?php if($item->pendidikan_ayah == 'SMA'): ?> selected <?php endif; ?> value="SMA">SMA
                                        </option>
                                        <option <?php if($item->pendidikan_ayah == 'D I'): ?> selected <?php endif; ?> value="D I">D I
                                        </option>
                                        <option <?php if($item->pendidikan_ayah == 'D III'): ?> selected <?php endif; ?> value="D III">D III
                                        </option>
                                        <option <?php if($item->pendidikan_ayah == 'S1'): ?> selected <?php endif; ?> value="S1">S1
                                        </option>
                                        <option <?php if($item->pendidikan_ayah == 'S2'): ?> selected <?php endif; ?> value="S2">S2
                                        </option>
                                        <option <?php if($item->pendidikan_ayah == 'S3'): ?> selected <?php endif; ?> value="S3">S3
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['pendidikan_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Penghasilan Ayah</label>
                                    <select name="penghasilan_ayah" id="" class="form-control form-select"
                                        value="<?php echo e(old('penghasilan_ayah')); ?>">
                                        <option value="">pilih</option>
                                        <option <?php if($item->penghasilan_ayah == '< Rp. 1.00.000'): ?> selected <?php endif; ?>
                                            value="< Rp. 1.00.000">
                                            < Rp. 1.00.000</option>
                                        <option <?php if($item->penghasilan_ayah == 'Rp. 1.00.000 - Rp. 250.000'): ?> selected <?php endif; ?>
                                            value="Rp. 1.00.000 - Rp. 250.000">Rp. 1.00.000 - Rp. 250.000</option>
                                        <option <?php if($item->penghasilan_ayah == 'Rp. 250.000 - Rp. 450.000'): ?> selected <?php endif; ?>
                                            value="Rp. 250.000 - Rp. 450.000">Rp. 250.000 - Rp. 450.000</option>
                                        <option <?php if($item->penghasilan_ayah == 'Rp. 450.000 - Rp. 1.000.000'): ?> selected <?php endif; ?>
                                            value="Rp. 450.000 - Rp. 1.000.000">Rp. 450.000 - Rp. 1.000.000</option>
                                        <option <?php if($item->penghasilan_ayah == 'Rp. 1.000.000 - Rp. 1.500.000'): ?> selected <?php endif; ?>
                                            value="Rp. 1.000.000 - Rp. 1.500.000">Rp. 1.000.000 - Rp. 1.500.000</option>
                                        <option <?php if($item->penghasilan_ayah == 'Rp. 1.500.000 - Rp. 2.000.000'): ?> selected <?php endif; ?>
                                            value="Rp. 1.500.000 - Rp. 2.000.000">Rp. 1.500.000 - Rp. 2.000.000</option>
                                        <option <?php if($item->penghasilan_ayah == '> Rp. 2.000.000'): ?> selected <?php endif; ?>
                                            value="> Rp. 2.000.000"> >
                                            Rp. 2.000.000</option>
                                    </select>
                                    <?php $__errorArgs = ['penghasilan_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Kode Pos</label>
                                    <input name="kode_pos_ayah" type="text" placeholder="Kode pos"
                                        class="form-control"value="<?php echo e($item->kode_pos_ayah); ?>">
                                    <?php $__errorArgs = ['kode_pos_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">No Hp</label>
                                    <input name="nohp_ayah" type="text" placeholder="No hp" class="form-control"
                                        value="<?php echo e($item->nohp_ayah); ?>">
                                    <?php $__errorArgs = ['nohp_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <hr class="horizontal dark">
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Nama Ibu Kandung</label>
                                    <input name="nama_ibu" type="text" placeholder="Nama Ibu Kandung"
                                        class="form-control" value="<?php echo e($item->nama_ibu); ?>">
                                    <?php $__errorArgs = ['nama_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">No KTP</label>
                                    <input name="no_ktp_ibu" type="text" placeholder="No KTP"
                                        class="form-control"value="<?php echo e($item->no_ktp_ibu); ?>">
                                    <?php $__errorArgs = ['no_ktp_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Tempat Lahir</label>
                                    <input name="tempat_lahir_ibu" type="text" placeholder="Tempat Lahir"
                                        class="form-control" value="<?php echo e($item->tempat_lahir_ibu); ?>">
                                    <?php $__errorArgs = ['tempat_lahir_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Tanggal Lahir</label>
                                    <input name="tanggal_lahir_ibu" type="date" placeholder="Tanggal Lahir"
                                        class="form-control"value="<?php echo e($item->tanggal_lahir_ibu); ?>">
                                    <?php $__errorArgs = ['tanggal_lahir_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Gol Darah</label>
                                    <input name="gol_darah_ibu" type="text" placeholder="Gol Darah"
                                        class="form-control"value="<?php echo e($item->gol_darah_ibu); ?>">
                                    <?php $__errorArgs = ['gol_darah_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Pekerjaan Ibu</label>
                                    <select name="pekerjaan_ibu" id="" class="form-control form-select"
                                        value="<?php echo e(old('pekerjaan_ibu')); ?>">
                                        <option value="">pilih</option>
                                        <option <?php if($item->pekerjaan_ibu == 'PNS'): ?> selected <?php endif; ?> value="PNS">PNS
                                        </option>
                                        <option <?php if($item->pekerjaan_ibu == 'BUMN/D'): ?> selected <?php endif; ?> value="BUMN/D">
                                            BUMN/D
                                        </option>
                                        <option <?php if($item->pekerjaan_ibu == 'Swasta'): ?> selected <?php endif; ?> value="Swasta">
                                            Swasta
                                        </option>
                                        <option <?php if($item->pekerjaan_ibu == 'Polri'): ?> selected <?php endif; ?> value="Polri">Polri
                                        </option>
                                        <option <?php if($item->pekerjaan_ibu == 'TNI'): ?> selected <?php endif; ?> value="TNI">TNI
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['pekerjaan_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Alamat Tempat Kerja</label>
                                    <textarea name="alamat_pekerjaan_ibu" type="text" placeholder="Alamat Kerja" class="form-control"
                                        value="<?php echo e(old('alamat_pekerjaan_ibu')); ?>"><?php echo e($item->alamat_pekerjaan_ibu); ?></textarea>
                                    <?php $__errorArgs = ['alamat_pekerjaan_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Pendidikan Ibu</label>
                                    <select name="pendidikan_ibu" id="" class="form-control form-select"
                                        value="<?php echo e(old('pendidikan_ibu')); ?>">
                                        <option value="">pilih
                                        </option>
                                        <option <?php if($item->pendidikan_ibu == 'SD'): ?> selected <?php endif; ?> value="SD">SD
                                        </option>
                                        <option <?php if($item->pendidikan_ibu == 'SMP'): ?> selected <?php endif; ?> value="SMP">SMP
                                        </option>
                                        <option <?php if($item->pendidikan_ibu == 'SMA'): ?> selected <?php endif; ?> value="SMA">SMA
                                        </option>
                                        <option <?php if($item->pendidikan_ibu == 'D I'): ?> selected <?php endif; ?> value="D I">D I
                                        </option>
                                        <option <?php if($item->pendidikan_ibu == 'D III'): ?> selected <?php endif; ?> value="D III">D III
                                        </option>
                                        <option <?php if($item->pendidikan_ibu == 'S1'): ?> selected <?php endif; ?> value="S1">S1
                                        </option>
                                        <option <?php if($item->pendidikan_ibu == 'S2'): ?> selected <?php endif; ?> value="S2">S2
                                        </option>
                                        <option <?php if($item->pendidikan_ibu == 'S3'): ?> selected <?php endif; ?> value="S3">S3
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['pendidikan_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Penghasilan Ibu</label>
                                    <select name="penghasilan_ibu" id="" class="form-control form-select"
                                        value="<?php echo e(old('penghasilan_ibu')); ?>">
                                        <option value="">pilih</option>
                                        <option <?php if($item->penghasilan_ibu == '< Rp. 1.00.000'): ?> selected <?php endif; ?>
                                            value="< Rp. 1.00.000">
                                            < Rp. 1.00.000</option>
                                        <option <?php if($item->penghasilan_ibu == 'Rp. 1.00.000 - Rp. 250.000'): ?> selected <?php endif; ?>
                                            value="Rp. 1.00.000 - Rp. 250.000">Rp. 1.00.000 - Rp. 250.000</option>
                                        <option <?php if($item->penghasilan_ibu == 'Rp. 250.000 - Rp. 450.000'): ?> selected <?php endif; ?>
                                            value="Rp. 250.000 - Rp. 450.000">Rp. 250.000 - Rp. 450.000</option>
                                        <option <?php if($item->penghasilan_ibu == 'Rp. 450.000 - Rp. 1.000.000'): ?> selected <?php endif; ?>
                                            value="Rp. 450.000 - Rp. 1.000.000">Rp. 450.000 - Rp. 1.000.000</option>
                                        <option <?php if($item->penghasilan_ibu == 'Rp. 1.000.000 - Rp. 1.500.000'): ?> selected <?php endif; ?>
                                            value="Rp. 1.000.000 - Rp. 1.500.000">Rp. 1.000.000 - Rp. 1.500.000</option>
                                        <option <?php if($item->penghasilan_ibu == 'Rp. 1.500.000 - Rp. 2.000.000'): ?> selected <?php endif; ?>
                                            value="Rp. 1.500.000 - Rp. 2.000.000">Rp. 1.500.000 - Rp. 2.000.000</option>
                                        <option <?php if($item->penghasilan_ibu == '> Rp. 2.000.000'): ?> selected <?php endif; ?>
                                            value="> Rp. 2.000.000"> >
                                            Rp. 2.000.000</option>
                                    </select>
                                    <?php $__errorArgs = ['penghasilan_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">Kode Pos</label>
                                    <input name="kode_pos_ibu" type="text" placeholder="Kode pos"
                                        class="form-control"value="<?php echo e($item->kode_pos_ibu); ?>">
                                    <?php $__errorArgs = ['kode_pos_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="form-control-label">No Hp</label>
                                    <input name="nohp_ibu" type="text" placeholder="No hp" class="form-control"
                                        value="<?php echo e($item->nohp_ibu); ?>">
                                    <?php $__errorArgs = ['nohp_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <hr class="horizontal dark">
                            <p class="text-uppercase text-sm">Foto Profile</p>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="example-text-input" class="form-control-label">Foto
                                            Profile</label>
                                        <input name="pas_foto" class="form-control" type="file">
                                    </div>
                                </div>
                            </div>
                            <hr class="horizontal dark">
                            
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary"
                                    data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- End Modal Update Data-->

    <!-- Modal Verifikasi Data-->
    <?php $__currentLoopData = $pendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="updatestatus<?php echo e($item->id); ?>" tabindex="-1"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Update Status </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(url('/dashboard/pendaftaran/update/status/' . $item->id)); ?>" method="Post">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="example-text-input" class="form-control-label">Verifikasi Data</label>
                                    <select class="form-control form-select" name="status_pendaftaran"
                                        aria-label=".form-select-sm example" id="">
                                        <option selected>Pilih...</option>
                                        <option value="Terverifikasi">Terverifikasi</option>
                                        <option value="Ditolak">Ditolak/cadangkan</option>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary"
                                    data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- End Modal Verifikasi Data-->

    <script>
        //Provinsi
        fetch('https://kanglerian.github.io/api-wilayah-indonesia/api/provinces.json')
            .then(response => response.json())
            .then(provinces => {
                var data = provinces;
                var tampung = '<option>Pilih Provinsi</option>';
                data.forEach(element => {
                    tampung +=
                        `<option data-reg="${element.id}" value="${element.name}">${element.name}</option>`
                });
                document.getElementById('provinsi').innerHTML = tampung;
            });

        //Kab/Kota
        const selectProvinsi = document.getElementById('provinsi');
        selectProvinsi.addEventListener('change', (e) => {
            var provinsi = e.target.options[e.target.selectedIndex].dataset.reg;
            fetch(`https://kanglerian.github.io/api-wilayah-indonesia/api/regencies/${provinsi}.json`)
                .then(response => response.json())
                .then(regencies => {
                    var data = regencies;
                    var tampung = '<option>Pilih Kab/Kota</option>';
                    data.forEach(element => {
                        tampung +=
                            `<option data-dist="${element.id}" value="${element.name}">${element.name}</option>`
                    });
                    document.getElementById('kota').innerHTML = tampung;
                });
        });

        //Kecamatan
        const selectKota = document.getElementById('kota');
        selectKota.addEventListener('change', (e) => {
            var kota = e.target.options[e.target.selectedIndex].dataset.dist;
            fetch(`https://kanglerian.github.io/api-wilayah-indonesia/api/districts/${kota}.json`)
                .then(response => response.json())
                .then(districts => {
                    var data = districts;
                    var tampung = '<option>Pilih Kecamatan</option>';
                    data.forEach(element => {
                        tampung +=
                            `<option data-vill="${element.id}" value="${element.name}">${element.name}</option>`
                    });
                    document.getElementById('kecamatan').innerHTML = tampung;
                });
        });

        //Kelurahan
        const selectKecamatan = document.getElementById('kecamatan');
        selectKecamatan.addEventListener('change', (e) => {
            var kecamatan = e.target.options[e.target.selectedIndex].dataset.vill;
            fetch(`https://kanglerian.github.io/api-wilayah-indonesia/api/villages/${kecamatan}.json`)
                .then(response => response.json())
                .then(villages => {
                    var data = villages;
                    var tampung = '<option>Pilih Kelurahan</option>';
                    data.forEach(element => {
                        tampung +=
                            `<option  value="${element.name}">${element.name}</option>`
                    });
                    document.getElementById('kelurahan').innerHTML = tampung;
                });
        });
    </script>

    <script>
        // Ambil nilai ID provinsi dari elemen tersembunyi
        var provinsiName = document.getElementById('provinsiName').value;

        // Ambil data provinsi dari API dan isi dropdown provinsi
        fetch('https://kanglerian.github.io/api-wilayah-indonesia/api/provinces.json')
            .then(response => response.json())
            .then(provinces => {
                var data = provinces;
                var tampung = '<option value="">Pilih Provinsi</option>';
                data.forEach(element => {
                    tampung +=
                        `<option data-reg="${element.id}" value="${element.name}">${element.name}</option>`;
                });
                document.getElementById('provinsi1').innerHTML = tampung;

                // Tentukan opsi provinsi yang dipilih berdasarkan data yang disimpan di database
                var selectedOption = document.querySelector(`#provinsi1 option[value="${provinsiName}"]`);
                if (selectedOption) {
                    selectedOption.selected = true;

                    // Ambil ID provinsi yang dipilih
                    var provinsiId = selectedOption.getAttribute('data-reg');

                    var kotaName = document.getElementById('kotaName').value;

                    // Ambil data kota/kabupaten dari API berdasarkan ID provinsi
                    fetch(`https://kanglerian.github.io/api-wilayah-indonesia/api/regencies/${provinsiId}.json`)
                        .then(response => response.json())
                        .then(regencies => {
                            var data = regencies;
                            var tampung = '<option value="">Pilih Kab/Kota</option>';
                            data.forEach(element => {
                                tampung +=
                                    `<option data-dist="${element.id}" value="${element.name}">${element.name}</option>`;
                            });
                            document.getElementById('kota1').innerHTML = tampung;

                            var selectedOption = document.querySelector(
                                `#kota1 option[value="${kotaName}"]`);

                            if (selectedOption) {
                                selectedOption.selected = true;

                                // Ambil ID provinsi yang dipilih
                                var kotaId = selectedOption.getAttribute('data-dist');

                                var kecamatanName = document.getElementById('kecamatanName').value;

                                fetch(
                                        `https://kanglerian.github.io/api-wilayah-indonesia/api/districts/${kotaId}.json`
                                    )
                                    .then(response => response.json())
                                    .then(districts => {
                                        var data = districts;
                                        var tampung = '<option value="">Pilih Kecamatan</option>';
                                        data.forEach(element => {
                                            tampung +=
                                                `<option data-vill="${element.id}" value="${element.name}">${element.name}</option>`;
                                        });
                                        document.getElementById('kecamatan1').innerHTML = tampung;

                                        var selectedOption = document.querySelector(
                                            `#kecamatan1 option[value="${kecamatanName}"]`);
                                        if (selectedOption) {
                                            selectedOption.selected = true;

                                            // Ambil ID provinsi yang dipilih
                                            var kecamatanId = selectedOption.getAttribute('data-vill');

                                            var kelurahanName = document.getElementById('kelurahanName').value;

                                            fetch(
                                                    `https://kanglerian.github.io/api-wilayah-indonesia/api/villages/${kecamatanId}.json`
                                                )
                                                .then(response => response.json())
                                                .then(villages => {
                                                    var data = villages;
                                                    var tampung =
                                                        '<option value="">Pilih Kelurahan</option>';
                                                    data.forEach(element => {
                                                        tampung +=
                                                            `<option value="${element.name}">${element.name}</option>`;
                                                    });
                                                    document.getElementById('kelurahan1').innerHTML =
                                                        tampung;
                                                    var selectedOption = document.querySelector(
                                                        `#kelurahan1 option[value="${kelurahanName}"]`);
                                                    if (selectedOption) {
                                                        selectedOption.selected = true;
                                                    }
                                                });
                                        }
                                    });
                            }
                        });
                }
            });

        // Event listener untuk dropdown provinsi
        document.getElementById('provinsi1').addEventListener('change', function(e) {
            var provinsiId = e.target.options[e.target.selectedIndex].getAttribute('data-reg');

            // Ambil data kota/kabupaten dari API berdasarkan ID provinsi yang dipilih
            fetch(`https://kanglerian.github.io/api-wilayah-indonesia/api/regencies/${provinsiId}.json`)
                .then(response => response.json())
                .then(regencies => {
                    var data = regencies;
                    var tampung = '<option value="">Pilih Kab/Kota</option>';
                    data.forEach(element => {
                        tampung +=
                            `<option data-dist="${element.id}" value="${element.name}">${element.name}</option>`;
                    });
                    document.getElementById('kota1').innerHTML = tampung;
                });
        });

        // Event listener untuk dropdown kota/kabupaten
        document.getElementById('kota1').addEventListener('change', function(e) {
            var kotaId = e.target.options[e.target.selectedIndex].getAttribute('data-dist');

            // Ambil data kecamatan dari API berdasarkan ID kota/kabupaten yang dipilih
            fetch(`https://kanglerian.github.io/api-wilayah-indonesia/api/districts/${kotaId}.json`)
                .then(response => response.json())
                .then(districts => {
                    var data = districts;
                    var tampung = '<option value="">Pilih Kecamatan</option>';
                    data.forEach(element => {
                        tampung +=
                            `<option data-vill="${element.id}" value="${element.name}">${element.name}</option>`;
                    });
                    document.getElementById('kecamatan1').innerHTML = tampung;
                });
        });

        // Event listener untuk dropdown kecamatan
        document.getElementById('kecamatan1').addEventListener('change', function(e) {
            var kecamatanId = e.target.options[e.target.selectedIndex].getAttribute('data-vill');

            // Ambil data kelurahan dari API berdasarkan ID kecamatan yang dipilih
            fetch(`https://kanglerian.github.io/api-wilayah-indonesia/api/villages/${kecamatanId}.json`)
                .then(response => response.json())
                .then(villages => {
                    var data = villages;
                    var tampung = '<option value="">Pilih Kelurahan</option>';
                    data.forEach(element => {
                        tampung +=
                            `<option value="${element.name}">${element.name}</option>`;
                    });
                    document.getElementById('kelurahan1').innerHTML = tampung;
                });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <!-- Tautkan file JavaScript jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="//cdn.datatables.net/2.0.1/js/dataTables.min.js"></script>
    <script>
        let table = new DataTable('#myTablee');
    </script>
    <script>
        $(document).ready(function() {
            $('#myTable').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eherd\OneDrive\Documents\Project\web_ppdb\resources\views/dashboard/pages/pendaftaran/pendaftaran.blade.php ENDPATH**/ ?>