
<?php $__env->startSection('title', 'User Account'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card mb-4">
                    
                    <div class="card-body px-0 pt-0 pb-2">
                        <div class="container-fluid py-4">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header pb-0">
                                            <div class="d-flex align-items-center">
                                                <p class="mb-0">Edit Profile</p>
                                                
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            
                                            <form action="<?php echo e(url('/dashboard/account/update/' . $accountUser->id)); ?>"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="example-text-input"
                                                                class="form-control-label">Username</label>
                                                            <input name="name" class="form-control" type="text"
                                                                value="<?php echo e($accountUser->name); ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="example-text-input" class="form-control-label">Email
                                                                address</label>
                                                            <input name="email" class="form-control" type="email"
                                                                value="<?php echo e($accountUser->email); ?>">
                                                        </div>
                                                    </div>

                                                    <div class="d-flex align-items-center">
                                                        
                                                        <button type="submit"
                                                            class="btn btn-primary btn-sm ms-auto">Submit</button>
                                                    </div>

                                                    
                                                </div>
                                                <hr class="horizontal dark">
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="footer pt-3  ">
            <?php echo $__env->make('dashboard.component.footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </footer>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eherd\OneDrive\Documents\Project\kta\resources\views/dashboard/pages/account/editAccount.blade.php ENDPATH**/ ?>